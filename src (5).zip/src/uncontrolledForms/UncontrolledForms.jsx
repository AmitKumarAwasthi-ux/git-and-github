import { useRef } from "react";

const UncontrolledForms = () => {
  let emailRef = useRef();
  let passwordRef = useRef();

  function formSubmit(e) {
    e.preventDefault();
    let user = {
      email: emailRef.current.value,
      password: passwordRef.current.value,
    };
    console.log(user);
  }

  return (
    <div>
      <h1>UncontrolledForms</h1>
      <form onSubmit={formSubmit}>
        <label>Email</label>
        <input type="text" ref={emailRef} />
        <br />
        <label>Password</label>
        <input type="text" ref={passwordRef} />
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default UncontrolledForms;
