import React, { useState } from "react";

const ControlledForms1 = () => {
  let [email, setEmail] = useState("");
  let [password, setPassword] = useState("");

  function handleEmail(e) {
    console.log(e);
    
    setEmail(e.target.value);
  }

  function handlePassword(e) {
    setPassword(e.target.value);
  }

  function formSubmit(e) {
    e.preventDefault();
    console.log({ email, password });
  }

  return (
    <div>
      <h1>Controlled Forms</h1>
      <form onSubmit={formSubmit}>
        <label>email</label>
        <input type="text" value={email} onChange={handleEmail}  />
        <br />
        <label>password</label>
        <input type="text" value={password} onChange={handlePassword} />
        <br />
        <button type="submit">submit</button>
      </form>
    </div>
  );
};

export default ControlledForms1;
