import React, { useState } from "react";

const ControlledForms2 = () => {
  let [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  function handleChange(e) {
    let { name, value } = e.target;
    console.log({ [name]: value });
    //            {email:"uytrerty",password:"qwerty"}
    setFormData({ ...formData, [name]: value });

    // setFormData({ ...formData, [name]: value });
  }

  function formSubmit(e) {
    e.preventDefault();
    console.log(formData);
  }

  return (
    <div>
      <h1>Controlled Forms2</h1>
      <form onSubmit={formSubmit}>
        <label>email</label>
        <input
          type="text"
          value={formData.email}
          name="email"
          onChange={handleChange}
        />
        <br />
        <label>password</label>
        <input
          type="text"
          value={formData.password}
          name="password"
          onChange={handleChange}
        />
        <br />
        <button type="submit">submit</button>
      </form>
    </div>
  );
};

export default ControlledForms2;
