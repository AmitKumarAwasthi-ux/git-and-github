import React from "react";

const InlineCss = () => {
  return (
    <div>
      <h1 style={{ backgroundColor: "red", color: "white" }}>Inline CSS</h1>
      <nav
        style={{
          height: "70px",
          width: "100%",
          backgroundColor: "lightblue",
          color: "blue",
        }}
      >
        I am nav
      </nav>
    </div>
  );
};

export default InlineCss;
