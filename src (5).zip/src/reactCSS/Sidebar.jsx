import React from "react";
import style from "./sidebar.module.css"

const Sidebar = () => {
  return (
    <aside id={style.sidebar}>
      <ul className={style.menu}>
        <li>Home</li>
        <li>About</li>
        <li>Services</li>
        <li>Projects</li>
        <li>Contact Us</li>
      </ul>
    </aside>
  );
};

export default Sidebar;
