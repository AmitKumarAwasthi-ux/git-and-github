import React from "react";

const PropsChild = ({ data: { data, arr } }) => {
  console.log(data, arr);
  return (
    <div>
      <h1>{data}</h1>
    </div>
  );
};

export default PropsChild;
