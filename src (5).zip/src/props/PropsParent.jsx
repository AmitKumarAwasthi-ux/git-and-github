import React, { useState } from "react";
import PropsChild from "./PropsChild";
import PropsChild2 from "./PropsChild2";

const PropsParent = () => {
  let [state, setState] = useState("");

  let data = "Hello";
  let arr = [10, 20, 30];
  return (
    <div>
      <PropsChild data={{ data, arr }} />

      <PropsChild2 setState={setState} />
      <h1>{state}</h1>
    </div>
  );
};

export default PropsParent;
