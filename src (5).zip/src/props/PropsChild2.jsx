import React from "react";

const PropsChild2 = ({ setState }) => {
  let data = "send me to parent";

  return (
    <div>
      <button onClick={() => setState(data)}>
        send data
      </button>
    </div>
  );
};

export default PropsChild2;
