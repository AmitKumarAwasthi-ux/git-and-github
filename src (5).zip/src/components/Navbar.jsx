function Navbar() {
  return (
    <nav>
      <ul>
        <li>home</li>
        <li>services</li>
        <li>login</li>
        <li>signup</li>
      </ul>
    </nav>
  );
}
export default Navbar
