import React from "react";

const DrillingChild2 = (y) => {
  console.log(y); //{prop2 : "send me to nested child" };

  return (
    <div>
      <h1>{y.prop2}</h1>
    </div>
  );
};

export default DrillingChild2;
