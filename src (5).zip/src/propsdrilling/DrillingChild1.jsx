import React from "react";
import DrillingChild2 from "./DrillingChild2";

const DrillingChild1 = (x) => {
  console.log(x); //{prop:"send me to nested child"}

  return (
    <div>
      <DrillingChild2 prop2={x.prop} />
    </div>
  );
};

export default DrillingChild1;
