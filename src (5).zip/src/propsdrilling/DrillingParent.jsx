import React from "react";
import DrillingChild1 from "./DrillingChild1";

const DrillingParent = () => {
  let val = "send me to nested child";
  return (
    <div>
      <DrillingChild1 prop={val} />
    </div>
  );
};

export default DrillingParent;
