import React from "react";
import style from "./myntranav.module.css";
import { MdAccountCircle } from "react-icons/md";
import { CiHeart } from "react-icons/ci";
import { IoBagOutline } from "react-icons/io5";
import logo from "./assets/myntra.avif"

const MyntraNav = () => {
  let menu = ["men", "women", "kids", "home&living", "beauty", "studio"];

  let options = [
    { title: "profile", logo: <MdAccountCircle /> },
    { title: "wishlist", logo: <CiHeart /> },
    { title: "bag", logo: <IoBagOutline /> },
  ];

  return (
    <nav id={style.navbar}>
      <figure>
        <img src={logo}/>
      </figure>
      <ul>
        {menu.map((ele, i) => {
          return <li key={i}>{ele}</li>;
        })}
      </ul>
      <section className={style.searchContainer}>searchContainer</section>
      <ul>
        {options.map((ele, i) => {
          let { title, logo } = ele;
          return (
            <li key={i}>
              <span>{logo}</span>
              {title}
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

export default MyntraNav;
