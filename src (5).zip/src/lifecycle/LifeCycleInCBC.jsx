import React, { Component } from "react";

export default class LifeCycleInCBC extends Component {
  state = { value: 0 };

  increment = () => {
    this.setState({ value: this.state.value + 1 });
  };

  componentDidMount() {
    console.log("Mounting phase");
    console.log(this);
  }

  componentDidUpdate() {
    console.log("Updating Phase");
  }

  componentWillUnmount() {
    console.log("Unmounting Phase");
  }

  render() {
    return (
      <div>
        <h1>LifeCycleInCBC {this.state.value}</h1>
        <button onClick={this.increment}>click</button>
      </div>
    );
  }
}
