import { useEffect, useState } from "react";

const LifeCycleInFBC = () => {
  let [state, setState] = useState(0);
  useEffect(() => {
    console.log("render");
  });

  useEffect(() => {
    console.log("Mounting phase");
    return () => {
      // cleanup function
      console.log("Unmounting phase");
    };
   
  }, []);

  useEffect(() => {
    console.log("Updating phase");
  }, [state]);

  return (
    <div>
      <h1>LifeCycleInFBC {state}</h1>
      <button onClick={() => setState(state + 1)}>click</button>
    </div>
  );
};

export default LifeCycleInFBC;
