import React from "react";
import Child2 from "./Child2";

const Child1 = () => {
  return (
    <div>
      <p>Child 1</p>
      <Child2 />
    </div>
  );
};

export default Child1;
