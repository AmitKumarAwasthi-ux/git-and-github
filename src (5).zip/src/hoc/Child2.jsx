import React from "react";
import Hoc from "./Hoc";
const Child2 = (feature) => {
  console.log(feature);

  return (
    <div>
      <p>Child 2</p>
    </div>
  );
};

export default Hoc(Child2);
