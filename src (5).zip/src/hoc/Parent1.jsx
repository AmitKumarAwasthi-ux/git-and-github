import React from "react";
import Child1 from "./Child1";
import Hoc from "./Hoc";
const Parent1 = (feature) => {
  console.log(feature);

  return (
    <div>
      <p>Parent 1</p>
      <Child1 />
    </div>
  );
};

export default Hoc(Parent1);
