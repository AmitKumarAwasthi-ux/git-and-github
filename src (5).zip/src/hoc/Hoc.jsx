const Hoc = (MyComponent) => {
  let p1Data = "hello";
  let c2Data = "bye";
  return function () {
    return <MyComponent feature={{ p1Data, c2Data }} />;
  };
};
export default Hoc;
