import { Component } from "react";
class StatesInCBC extends Component {
  state = { value: "Hii" };

  update = () => {
    this.setState({ value: "byeee" });
  };

  render() {
    return (
      <div>
        <h1>States in CBC {this.state.value}</h1>
        <button onClick={this.update}>click</button>
      </div>
    );
  }
}
export default StatesInCBC;
