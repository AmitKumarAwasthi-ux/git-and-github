import { useState } from "react";

const StatesInFBC2 = () => {
    let [cartBtn,setCartBtn] = useState("add to cart")
    function addToCart(){
        setCartBtn("go to cart")
    }
  return (
    <div>
      <h1>Create Add to cart button</h1>
      <button onClick={addToCart}>{cartBtn}</button>
    </div>
  );
};

export default StatesInFBC2;
