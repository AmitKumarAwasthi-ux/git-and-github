import { useState } from "react";
const StatesInFBC = () => {
  // console.log(useState());//[undefined, ƒ]
  let [state, setState] = useState("Hello");

  function changeData() {
    setState("Byeee");
  }

  return (
    <div>
      <h1>Learn States {state}</h1>
      <button onClick={changeData}>click</button>
    </div>
  );
};
export default StatesInFBC;
