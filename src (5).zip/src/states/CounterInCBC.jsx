import { Component } from "react";

class CounterInCBC extends Component {
  state = { value: 0 };
  increment = () => {
    if (this.state.value < 10) {
      this.setState({ value: this.state.value + 1 });
    } else {
      this.setState({ value: "limit Exceeded" });
    }
  };
  render() {
    return (
      <div>
        <h1>Counter {this.state.value}</h1>
        <button onClick={this.increment}>increment</button>
      </div>
    );
  }
}
export default CounterInCBC;
