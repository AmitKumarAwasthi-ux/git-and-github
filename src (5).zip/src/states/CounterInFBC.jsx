import { useState } from "react";

const CounterInFBC = () => {
  let [count, setCount] = useState(0);

  function increment() {
    if (count < 10) {
      setCount(count + 1);
    } else {
      setCount("Limit Exceeded");
    }
  }
  function decrement() {
    if (count > 0) {
      setCount(count - 1);
    }
  }
  function reset() {
    setCount(0);
  }
  return (
    <div>
      <h1>Counter {count}</h1>
      <button onClick={increment}>increment</button>
      <button onClick={decrement}>decrement</button>
      <button onClick={reset}>reset</button>
    </div>
  );
};

export default CounterInFBC;
