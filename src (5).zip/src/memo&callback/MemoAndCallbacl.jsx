import React, { useState, useMemo, useCallback } from "react";
import Child from "./Child";

const MemoAndCallback = () => {
  let [add, setAdd] = useState(0);
  let [minus, setMinus] = useState(100);

  //useMemo will only recompute the memoized value when one of the deps has changed.
  let memoizedVal = useMemo(() => {
    console.log("multiply");
    return add * 10;
  }, [add]);

  //   function mul() {
  //     console.log("multiply");
  //     return add * 10;
  //   }

  let memoizedFunc = useCallback(() => {
    console.log("hii");
  }, []);

  //   function display() {
  //     console.log("hii");
  //   }

  return (
    <div>
      <Child display={memoizedFunc} />
      <h1>
        Addition {add} <button onClick={() => setAdd(add + 1)}>add</button>
      </h1>

      <h1>
        Minus {minus} <button onClick={() => setMinus(minus - 1)}>minus</button>
      </h1>

      <h1>Multiply {memoizedVal}</h1>
    </div>
  );
};

export default MemoAndCallback;
