import React from "react";

const Child = (x) => {
    console.log("child");
    x.display()
  return (
    <div>
      <h1>Child</h1>
    </div>
  );
};

export default React.memo(Child);
