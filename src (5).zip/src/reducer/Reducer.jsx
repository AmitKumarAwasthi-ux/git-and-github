import { useReducer } from "react";

let initialState = 0;

function reducerFunc(prevState, action) {
  switch (action) {
    case "increment":
      return prevState + 1;
    case "decrement":
      return prevState - 1;
    case "reset":
      return 0;
    default:
      break;
  }
}

const Reducer = () => {
  let [state, dispatch] = useReducer(reducerFunc, initialState);
  // state: it will store state value
  // dispatch: it is used to send an action to reducerFunc
  return (
    <div>
      <h1>Learn useRedducer</h1>
      <h1>Count {state}</h1>
      <button onClick={() => dispatch("increment")}>increment</button>
      <button onClick={() => dispatch("decrement")}>decrement</button>
      <button onClick={() => dispatch("reset")}>reset</button>
    </div>
  );
};

export default Reducer;
