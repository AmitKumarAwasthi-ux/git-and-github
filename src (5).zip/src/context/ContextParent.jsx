import { createContext } from "react";
import ContextChild1 from "./ContextChild1";

//STEP1:-> creating a context
export let storeRoom = createContext();

const ContextParent = () => {
  let data = "hello";
  return (
    <div>
      <h1>ContextParent</h1>
      {/* STEP2:-> providing a context */}
      <storeRoom.Provider value={data}>
        <ContextChild1 />
      </storeRoom.Provider>
    </div>
  );
};

export default ContextParent;
