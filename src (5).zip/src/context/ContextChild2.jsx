import { useContext } from "react";
import { storeRoom } from "./ContextParent";
const ContextChild2 = () => {
  // STEP3:-> consume a context
  let val = useContext(storeRoom);
  console.log(val);

  return (
    <div>
      <h1>ContextChild2 {val}</h1>
    </div>
  );
};

export default ContextChild2;
