import StatesInFBC from "./states/StatesInFBC";
import StatesInFBC2 from "./states/StatesInFBC2";
import CounterInFBC from "./states/CounterInFBC";
import StatesInCBC from "./states/StatesInCBC";
import CounterInCBC from "./states/CounterInCBC";
import PropsParent from "./props/PropsParent";
import DrillingParent from "./propsdrilling/DrillingParent";
import InlineCss from "./reactCSS/InlineCss";
import Sidebar from "./reactCSS/Sidebar";
import MyntraNav from "./task1/MyntraNav";
import ControlledForms1 from "./controlledForms/ControlledForms1";
import ControlledForms2 from "./controlledForms/ControlledForms2";
import UncontrolledForms from "./uncontrolledForms/UncontrolledForms";
import Reducer from "./reducer/Reducer";
import ContextParent from "./context/ContextParent";
import Parent1 from "./hoc/Parent1";
import LifeCycleInCBC from "./lifecycle/LifeCycleInCBC";
import LifeCycleInFBC from "./lifecycle/LifeCycleInFBC";
import MemoAndCallback from "./memo&callback/MemoAndCallbacl";

const App = () => {
  return (
    <div>
      {/* <StatesInFBC/>
      <StatesInFBC2/>
      <CounterInFBC/> */}
      {/*  <StatesInCBC/>
      <CounterInCBC/> */}

      {/*  <PropsParent/> */}

      {/* <DrillingParent /> */}

      {/* <InlineCss/> */}
      {/*  <Sidebar/> */}

      {/*  <MyntraNav/> */}
      {/* <ControlledForms2 /> */}
      {/* <UncontrolledForms/> */}

      {/* <Reducer/> */}
      {/*  <ContextParent/> */}

      {/* <Parent1 /> */}
      {/* <LifeCycleInCBC/> */}
      {/* <LifeCycleInFBC /> */}
      <MemoAndCallback />
    </div>
  );
};
export default App;
