package immutableClass;
public final class Car {//Immutable class
	
	final private String name;
	final private double price;
	final private String color;
	Car(String name, double price, String color){
		this.name=name;
		this.price=price;
		this.color=color;
	}
	public String getName() {
	return name;
	}
	public double getPrice() {
	return price;
	}
	public String getColor() {
	return color;
	}
	

}
