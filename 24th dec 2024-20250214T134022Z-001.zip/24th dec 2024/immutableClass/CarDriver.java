package immutableClass;

public class CarDriver {
	public static void main(String[] args) {
		Car c1=new Car("TATA", 346457.56, "White");
		System.out.println("Name is: "+c1.getName());
		System.out.println("Price is: "+c1.getPrice());
		System.out.println("Color is: "+c1.getColor());
	}

}
