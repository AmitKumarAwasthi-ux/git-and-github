class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is Java progarm1");	
			
	}
}

class Program2
{
	public static void main(String[] args)
	{
		System.out.println("This is Java progarm2");
	}

}

class Program3
{
	public static void main(String[] args)
	{
		System.out.println("This is Java progarm3");
	}

}

