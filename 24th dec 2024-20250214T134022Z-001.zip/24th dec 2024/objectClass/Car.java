package objectClass;

public class Car {
	String name;
	int hp;
	double price;
	
	public boolean equals(Object o) {
		if(this==o)
			return true;
		if(!(o instanceof Car))
			return false;
		Car c=(Car)o;
	return this.name.equals(c.name) && 
			this.hp==c.hp && this.price==c.price; 
	}

}
