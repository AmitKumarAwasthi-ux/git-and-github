package objectClass;

public class FruitDriver {
	public static void main(String[] args) {
		Fruit f1=new Fruit("Mango", 123, 3.4, 111);
		Fruit f2=new Fruit("Apple", 180, 2.4, 124);
		Fruit f3=new Fruit("Mango", 123, 3.4, 111);
		System.out.println("========toString()==========");
		System.out.println(f1);
		System.out.println(f2);
		System.out.println(f3);
		System.out.println("======hashCode()==============");
		System.out.println(f1.hashCode());
		System.out.println(f2.hashCode());
		System.out.println(f3.hashCode());
		System.out.println("========equals()===============");
		System.out.println(f1==f1);
		System.out.println(f1==f2);
		System.out.println(f1==f3);
		System.out.println("==============");
		Car c1=new Car();
		System.out.println(f1.equals(f2));
		System.out.println(f1.equals(f3));
		System.out.println(f1.equals(c1));
		System.out.println("======getClass()===========");
		System.out.println(f1.getClass());
		System.out.println(f1.getClass().getName());
		System.out.println("===========finalize()=============");
		f1=null;
		f2=null;
		System.gc();
	}

}
