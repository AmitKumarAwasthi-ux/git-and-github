package objectClass;

public class Program1 {
	public static void main(String[] args) {
		Fruit f1=new Fruit();
		String s1=new String("Mohan");
		String s2=new String("Mohan");
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(f1));
	}

}
