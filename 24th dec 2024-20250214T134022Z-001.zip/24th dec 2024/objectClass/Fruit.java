package objectClass;

public class Fruit {
	String name;
	int price;
	double weight;
	int id;
	Fruit(){
		
	}
	Fruit(String name, int price, double weight, int id){
		this.name=name;
		this.price=price;
		this.weight=weight;
		this.id=id;
	}
	@Override
	public String toString() {
	return "Name is: "+name+"\tPrice is: "+price+"\tWeight is: "+weight+"\tID is: "+id;
	}
	@Override
	public int hashCode() {
	return id;	
	}
	@Override
	public boolean equals(Object o) {
		if(this==o)
			return true;
		if(!(o instanceof Fruit))
			return false;
		Fruit f=(Fruit)o;
		return this.name.equals(f.name) &&
				this.price==f.price && this.weight==f.weight;
	/*return	o instanceof Fruit f && this.name.equals(f.name)
	 *  && this.price==f.price && this.weight==f.weight;*/
	
	}
	public void finalize() {
		System.out.println("Close database connection");
		System.out.println("close file connections");
		System.out.println("==========================");
		
	}

}




