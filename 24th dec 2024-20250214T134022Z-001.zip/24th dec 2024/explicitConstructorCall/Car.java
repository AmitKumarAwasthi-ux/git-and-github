package explicitConstructorCall;

public class Car extends Vehicle{
	
	Car(){
		super(28);
		System.out.println("Car No-arg constructor");
	}
	Car(int x){
		super(38);
		
		System.out.println("Car int-arg constructor");
		
		}

}
