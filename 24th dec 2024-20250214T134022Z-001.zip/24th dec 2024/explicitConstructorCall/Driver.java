package explicitConstructorCall;

public class Driver {
	public static void main(String[] args) {
		Car c1=new Car(23);
	}

}
