package explicitConstructorCall;

public class Vehicle {
	Vehicle(){
		System.out.println("Vehicle No-arg constructor");
	}
	Vehicle(int x){
		System.out.println("Vehicle int-arg constructor");
	}

}
