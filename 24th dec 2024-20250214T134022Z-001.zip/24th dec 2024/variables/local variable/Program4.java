
class Program4
{
	public static void main(String[] args)
	{
		{
			int a=34;
			System.out.println(a);
		}
		{
			int a=56;
			System.out.println(a);
		}
	}
}