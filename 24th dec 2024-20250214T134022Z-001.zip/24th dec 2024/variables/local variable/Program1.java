
class Program1
{
	public static void main(String[] args)
	{
		int a;
		System.out.println("abc");
		int b=a+10;
	}
}