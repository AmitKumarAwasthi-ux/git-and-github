
class Program5
{
	public static void main(String[] args)
	{
		int x=1000;
		char y=(char)x;
		System.out.println("x is: "+x);
		System.out.println("y is: "+y);
	}
}