
class Program2
{
	public static void main(String[] args)
	{
		int a=30;
		System.out.println(a);
		{
			int b=20;
			System.out.println(a);
			System.out.println(b);
		}
		System.out.println(a);
		System.out.println(b);
	}
}