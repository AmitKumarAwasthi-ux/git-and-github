class Laptop
{	
	static int x;
	int y;
	static String s;
	static Laptop l;
	public static void main(String[] args)
	{
		System.out.println("This is Laptop class");
		System.out.println(Laptop.x);
		System.out.println(Laptop.s);
		System.out.println(Laptop.l);
		Laptop l1=new Laptop();
		System.out.println(l1.y);
	}
}
