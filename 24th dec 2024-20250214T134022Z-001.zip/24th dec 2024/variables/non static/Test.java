class Test
{	
	int x=11;
	int a=33;
	public static void main(String[] args)
	{
		System.out.println("This is Test class");
		Test t1=new Test();
		System.out.println(t1.x);
		System.out.println(t1.a);
		System.out.println("==============");
		Fruit f1=new Fruit();
		System.out.println(f1.x);
		System.out.println(f1.y);
	
	}
}
