class Test1
{
	public static void main(String[] args)
	{
		System.out.println("This is Test1 class");
		System.out.println(Math.E);
		System.out.println(Math.PI);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);



	}
}