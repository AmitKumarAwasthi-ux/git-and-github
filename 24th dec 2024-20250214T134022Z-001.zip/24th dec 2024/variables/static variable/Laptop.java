
class Laptop
{
	static int x=45;
	static int y=450;
}