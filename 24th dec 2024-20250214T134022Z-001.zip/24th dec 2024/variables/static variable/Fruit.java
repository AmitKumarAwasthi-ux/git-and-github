
class Fruit
{
	static int a=22;
	static int x=220;
}