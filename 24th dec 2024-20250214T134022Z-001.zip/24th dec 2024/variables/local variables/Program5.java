class Program5
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm1");
		int x;
		{
			int a=50;
			x=77;
			System.out.println(a);
			System.out.println(x);
			x=65;
		}
		System.out.println(x);
	}
}
