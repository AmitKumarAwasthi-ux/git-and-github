class Program2
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm1");
		int x=23;
		int x=45;
		System.out.println("Hi");
	}
}
