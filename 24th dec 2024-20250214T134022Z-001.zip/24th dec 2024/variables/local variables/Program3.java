class Program3
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm1");
		int x=23;
		System.out.println(x);
		x=50;
		System.out.println(x);
		x=100;
		System.out.println(x);
	}
}
