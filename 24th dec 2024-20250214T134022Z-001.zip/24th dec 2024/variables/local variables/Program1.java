class Program1
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm1");
		int x;
		System.out.println("Hi");
		//int y=x+20;
	}
}
