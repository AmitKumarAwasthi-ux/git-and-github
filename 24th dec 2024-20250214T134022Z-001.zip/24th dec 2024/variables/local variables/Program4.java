class Program4
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm1");
		int x=23;
		System.out.println(x);
		{
			int a=50;
			System.out.println(a);
			System.out.println(x);
		}
		System.out.println(x);
		//System.out.println(a);
	}
}
