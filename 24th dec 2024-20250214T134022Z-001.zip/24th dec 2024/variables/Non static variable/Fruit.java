
class Fruit
{
	int a=22;
	int x=220;
}