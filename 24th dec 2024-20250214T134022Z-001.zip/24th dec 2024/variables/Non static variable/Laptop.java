
class Laptop
{
	int x=45;
	int y=450;
}