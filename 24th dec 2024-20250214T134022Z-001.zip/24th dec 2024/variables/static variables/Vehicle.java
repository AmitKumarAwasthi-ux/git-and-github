class Vehicle
{
	static int x=777;
}
