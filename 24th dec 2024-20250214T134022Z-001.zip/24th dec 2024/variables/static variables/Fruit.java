class Fruit
{
	static int x=555;
}
