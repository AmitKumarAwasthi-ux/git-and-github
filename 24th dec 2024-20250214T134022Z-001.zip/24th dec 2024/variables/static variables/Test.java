class Test
{	
	static int x=44;
	public static void main(String[] args)
	{
		System.out.println("This is Test class");
		System.out.println(x);
		System.out.println(Test.x);
		System.out.println("==========");
		System.out.println(Fruit.x);
		System.out.println("===========");
		System.out.println(Vehicle.x);	
	}
}
