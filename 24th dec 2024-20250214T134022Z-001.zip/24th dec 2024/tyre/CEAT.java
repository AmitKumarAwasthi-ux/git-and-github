package tyre;

 class CEAT {
	 public static void main(String[] args) {
			System.out.println("This is CEAT class");
			System.out.println("a is: "+MRF.a);
			MRF.test();
			System.out.println("b is: "+MRF.b);
			MRF.demo();
			System.out.println("c is: "+MRF.c);
			MRF.start();
		}

}
