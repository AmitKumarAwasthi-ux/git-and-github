package tyre;

public class MRF {
	public static int a=12;
	protected static int b=22;
	static int c=32;
	private static int d=42;
	public static void test() {
		System.out.println("public type test method");
	}
	protected static void demo() {
		System.out.println("protected type demo method");
	}
	static void start() {
		System.out.println("default type start method");
	}
	private static void drive() {
		System.out.println("private type drive method");
	}
	public static void main(String[] args) {
		System.out.println("This is MRF class");
		System.out.println("a is: "+a);
		test();
		System.out.println("b is: "+b);
		demo();
		System.out.println("c is: "+c);
		start();
		System.out.println("d is: "+d);
		drive();
	}
	

}








