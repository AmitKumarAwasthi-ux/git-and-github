package initializationByMethod;

public class Cylinder {
	double r;
	double h;
	public void setValue(double r, double h) {
		this.r=r;
		this.h=h;
	}
	public void getDetails() {
		System.out.println("Radius is: "+r+" unit");
		System.out.println("height is: "+h+" unit");
	}
	public void getVolume() {
		System.out.println("Volume is: "+Math.PI*r*r*h+" Cub. Unit");
	}
	public void getLSA() {
		System.out.println("LSA is: "+2*Math.PI*r*h+" Sq. Unit");
	}
	public void getTSA() {
		System.out.println("TSA is: "+2*Math.PI*r*(r+h)+" Sq. Unit");
	}

}
