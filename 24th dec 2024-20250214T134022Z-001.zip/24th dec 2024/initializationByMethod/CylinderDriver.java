package initializationByMethod;

public class CylinderDriver {
	public static void main(String[] args) {
		System.out.println("Main Starts");
		Cylinder c1=new Cylinder();
		Cylinder c2=new Cylinder();
		Cylinder c3=new Cylinder();
		//Cylinder c4=new Cylinder(12, 18);
		c1.setValue(12, 18);
		c2.setValue(11, 3.4);
		c3.setValue(45, 34.7);
		
		c1.getDetails();
		c1.getVolume();
		c1.getLSA();
		c1.getTSA();
		System.out.println("=============");
		c2.getDetails();
		c2.getVolume();
		c2.getLSA();
		c2.getTSA();
		System.out.println("=============");
		c3.getDetails();
		c3.getVolume();
		c3.getLSA();
		c3.getTSA();
	}

}
