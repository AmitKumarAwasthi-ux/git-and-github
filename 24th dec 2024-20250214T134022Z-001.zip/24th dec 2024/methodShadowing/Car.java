package methodShadowing;

public class Car extends Vehicle{
	
	@Override
	public void test() {
		System.out.println("Test Car");
	}
	
	public static void demo() {
		System.out.println("Demo Car");
	}

}
