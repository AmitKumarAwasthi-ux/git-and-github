package methodShadowing;

public class Vehicle {
	
	public  void test() {
		System.out.println("Test Vehicle");
	}
	
	public static void demo() {
		System.out.println("Demo Vehicle");
	}
	
	
	
	
	

}
