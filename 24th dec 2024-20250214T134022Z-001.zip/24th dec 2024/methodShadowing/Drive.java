package methodShadowing;

public class Drive {
	public static void main(String[] args) {
		Vehicle.demo();
		Car.demo();
		System.out.println("============");
		Vehicle v1=new Car();
		v1.test();//Test Car
		v1.demo();//Test Vehicle
		
	}

}
