class Program4
{
	public static void main(String[] args)
	{
		System.out.println("This is my Java Program4");
		int[] a={12, 34,45, 32, 16, 22};
		System.out.println(a);
		System.out.println(a.length);
		System.out.println(a[3]);
		System.out.println(a[0]);
		System.out.println(a[6]);

	}
}