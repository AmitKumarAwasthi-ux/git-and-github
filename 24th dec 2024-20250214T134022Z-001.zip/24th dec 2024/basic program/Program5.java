class Program5
{
	public static void main(String[] args)
	{
		System.out.println("This is my Java Program5");
		int[] a={12, 34,45, 32, 16, 22};
		for(int p: a){
			System.out.println(p);
		}
	}
}