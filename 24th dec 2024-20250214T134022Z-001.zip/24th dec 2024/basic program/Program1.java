class Program1
{
	public static void main(String[] args)
	{
		System.out.println("Java Program");
		System.out.println(12+35*4);
	}
}