class Program2
{
	public static void main(String[] args)
	{
		System.out.println("This is my Java Program2");
		System.out.println(12+35/4);
	}
}