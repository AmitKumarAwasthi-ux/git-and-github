class Program3
{
	public static void main(String[] args)
	{
		System.out.println("This is my Java Program3");
		String s1="Mohan is here";
		System.out.println(s1);
		System.out.println(s1.length());
		System.out.println(s1.toUpperCase());
		System.out.println(s1.toLowerCase());
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(9));
		System.out.println(s1.charAt(13));

	}
}