class Program2
{
	public static void main(String[] args)
	{
		char x='}';
		int y=x;
		System.out.println("x is: "+x);
		System.out.println("y is: "+y);

	}
}
