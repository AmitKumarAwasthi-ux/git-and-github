class Program3
{
	public static void main(String[] args)
	{
		double x=34.56;
		int y=(int)x;
		System.out.println("x is: "+x);
		System.out.println("y is: "+y);

	}
}
