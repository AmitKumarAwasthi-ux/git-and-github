class Program5
{
	public static void main(String[] args)
	{
		System.out.println((double)123);
		System.out.println((int)123.56);

		System.out.println("==================");

		System.out.println((char)123);
		System.out.println((int)']');


		

	}
}
