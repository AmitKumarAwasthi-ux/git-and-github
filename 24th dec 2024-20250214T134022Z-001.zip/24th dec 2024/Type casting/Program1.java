class Program1
{
	public static void main(String[] args)
	{
		int x=45;
		double y=x;
		System.out.println("x is: "+x);
		System.out.println("y is: "+y);

	}
}
