package methodOverloading;

public class Calculator {
	
	public static void add(int a, int b) {
		System.out.println("add int, int method");
		System.out.println("sum is: "+(a+b));
	}
	public static void add(int a, double b) {
		System.out.println("add int, double method");
		System.out.println("sum is: "+(a+b));
	}
	public static void add(double a, int b) {
		System.out.println("add double, int method");
		System.out.println("sum is: "+(a+b));
	}
	public static void add4(double a, double b) {
		System.out.println("add double, double method");
		System.out.println("sum is: "+(a+b));
	}
	public static void add(int a, int b, int c) {
		System.out.println("add int, int, int method");
		System.out.println("sum is: "+(a+b+c));
	}
	public static void add(int a, double b, int c) {
		System.out.println("add int, double, int method");
		System.out.println("sum is: "+(a+b+c));
	}
	public static void add(int a, int b, double c) {
		System.out.println("add int, int, double method");
		System.out.println("sum is: "+(a+b+c));
	}
	public static void add(double a, int b, int c) {
		System.out.println("double ,int, int method");
		System.out.println("sum is: "+(a+b+c));
	}
	public static void add(double a, double b, double c) {
		System.out.println("add int, int, int method");
		System.out.println("sum is: "+(a+b+c));
	}
	

}
