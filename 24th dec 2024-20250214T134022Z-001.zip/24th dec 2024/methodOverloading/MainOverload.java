package methodOverloading;

public class MainOverload {
	public static void main(int args) {
		System.out.println("main with int");
	}
	public static void main(String[] args) {
		System.out.println("main with String[]");
		main("abc");
		main(23.4);
	}
	public static void main(double args) {
		System.out.println("main with double");
	}
	public static void main(String args) {
		System.out.println("main with String");
	}

}
