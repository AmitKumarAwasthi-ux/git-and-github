package methodOverloading;

public class Driver {
	public static void main(String[] args) {
			System.out.println(12+34);
		Calculator.add(23.5, 44);
		System.out.println("===========");
		Calculator.add(34, 45.6, 77);
		System.out.println("===========");
		Calculator.add(12.4, 55, 44);
	}

}
