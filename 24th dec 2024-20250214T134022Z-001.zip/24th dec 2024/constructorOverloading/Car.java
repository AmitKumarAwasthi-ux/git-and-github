package constructorOverloading;

public class Car {
	Car(){
		System.out.println("Car No-Arg Constructor");
	}
	Car(int x){
		System.out.println("Car int-Arg Constructor");
	}
	Car(double x){
		System.out.println("Car double-Arg Constructor");
	}
	Car(String x){
		System.out.println("Car String-Arg Constructor");
	}

}
