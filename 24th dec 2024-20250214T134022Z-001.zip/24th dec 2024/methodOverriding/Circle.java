package methodOverriding;

public class Circle extends TwoDShape{
	
	@Override
	public void area() {
		System.out.println("Area of CIrcle is PI*r*r");
	}


}
