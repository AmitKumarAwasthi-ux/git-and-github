package methodOverriding;

public class Rectangle extends TwoDShape{
	
	@Override
	public void area() {
		System.out.println("Area of Rectangle is l*w");
	}

}
