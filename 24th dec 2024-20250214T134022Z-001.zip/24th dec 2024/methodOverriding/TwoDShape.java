package methodOverriding;

public class TwoDShape {
	
	public void area() {
		System.out.println("Area of TwoD Shape");
	}

}
