package copyConstructor;
import java.util.*;
public class CarDriver {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name: ");
		String name1=sc.nextLine();
		System.out.println("Enter the price: ");
		int price1=sc.nextInt();
		System.out.println("Enter the Color: ");
		sc.nextLine();
		String color1=sc.nextLine();
		System.out.println("Enter the HP: ");
		int hp1=sc.nextInt();
		Car c1=new Car(name1, price1, color1, hp1);
		Car c2=new Car("HONDA", 4543656, "Red");
		Car c3=new Car("Audi", 7543656, "Black");
		
		Car c4=new Car(c2);
		Car c5=new Car(c1);
		Car c6=new Car(c2);
		
		
		System.out.println("==================");
		c1.getDetails();
		c2.getDetails();
		c3.getDetails();
		c4.getDetails();
		c5.getDetails();
		c6.getDetails();
		
	}


}
