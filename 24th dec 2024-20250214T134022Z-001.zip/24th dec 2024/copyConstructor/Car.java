package copyConstructor;

public class Car {
	String name;
	int price;
	String color;
	int hp;
	
	Car(String name, int price, String color){
		this.name=name;
		this.price=price;
		this.color=color;
	}
	Car(String name, int price, String color, int hp){
		this(name, price, color);
		this.hp=hp;
	}
	Car(Car p){
		this.name=p.name;
		this.price=p.price;
		this.color=p.color;
		this.hp=p.hp;
	}
	public void getDetails() {
		System.out.println("Name is: "+name);
		System.out.println("Price is: "+price);
		System.out.println("Color is: "+color);
		System.out.println("HP is: "+hp);
		System.out.println("===================");
	}


}
