package inheritance;

public class Car extends Vehicle{
	
	int a=50;
	int b=70;
	
	Car(){
		super("TATA");
	}

}
