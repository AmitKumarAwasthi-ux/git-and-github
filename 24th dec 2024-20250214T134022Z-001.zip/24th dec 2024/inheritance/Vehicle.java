package inheritance;

public class Vehicle {

	int x=12;
	int y=30;
	
	Vehicle(String p){
		
	}

}
