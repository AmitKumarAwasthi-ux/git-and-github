package nonPrimitiveCasting;

public class Bike extends Vehicle{
	int c=50;

}
