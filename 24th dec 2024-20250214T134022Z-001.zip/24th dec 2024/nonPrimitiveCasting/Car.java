package nonPrimitiveCasting;

public class Car extends Vehicle{
	int a=20;

}
