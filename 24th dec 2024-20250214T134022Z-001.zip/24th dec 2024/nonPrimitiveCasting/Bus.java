package nonPrimitiveCasting;

public class Bus extends Vehicle{
	int b=30;

}
