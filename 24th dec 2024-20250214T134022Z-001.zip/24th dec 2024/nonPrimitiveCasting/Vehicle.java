package nonPrimitiveCasting;

public class Vehicle {
	int x=10;

}
