package weaponGame;

public class Bomb extends Weapon{
	
	public void use() {
		System.out.println("Use the Bomb");
		System.out.println("Unpin it");
		System.out.println("Aim at enemy and throw it...");
	}

}
