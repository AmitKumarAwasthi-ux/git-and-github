package weaponGame;

public class Weapon {
	
	public void use() {
		System.out.println("Use the Weapon");
	}

}
