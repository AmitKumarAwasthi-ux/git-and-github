package weaponGame;

public class Knife extends Weapon{
	
	public void use() {
		System.out.println("Use the Knife");
		System.out.println("Swing it");
		System.out.println("And stab with it...");
	}
	
	

}
