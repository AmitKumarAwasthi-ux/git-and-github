package constructorChaining;

public class Car {
	String name;
	int price;
	String color;
	int hp;
	Car(){
		System.out.println("car Object is created!");
	}
	Car(String name){
		this();
		this.name=name;
	}
	Car(String name, int price){
		this(name);
		this.price=price;
	}
	Car(String name, int price, String color){
		this(name, price);
		this.color=color;
	}
	Car(String name, int price, String color, int hp){
		this(name, price, color);
		this.hp=hp;
	}
	public void getDetails() {
		System.out.println("Name is: "+name);
		System.out.println("Price is: "+price);
		System.out.println("Color is: "+color);
		System.out.println("HP is: "+hp);
		System.out.println("===================");
	}

}
