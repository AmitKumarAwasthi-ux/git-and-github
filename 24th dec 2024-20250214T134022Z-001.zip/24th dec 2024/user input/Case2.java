import java.util.Scanner;
class Case2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Age: ");
		int age=sc.nextInt();
		System.out.println("Enter Name: ");
		sc.nextLine();
		String name=sc.nextLine();
		System.out.println("Enter Weight: ");
		double weight=sc.nextDouble();
		System.out.println("Enter Address: ");
		sc.nextLine();
		String address=sc.nextLine();
		System.out.println("Enter PIN: ");
		int pin=sc.nextInt();
		System.out.println("Enter Country: ");
		sc.nextLine();
		String country=sc.nextLine();
		System.out.println("Enter Email ID: ");
		String emailid=sc.nextLine();
		System.out.println("Enter House No: ");
		String houseno=sc.nextLine();
		System.out.println("====Entered Details are Below:=======");
		System.out.println("Name is: "+name);
		System.out.println("Age is: "+age+" Years");
		System.out.println("Weight is: "+weight+" Kg");
		System.out.println("Address is: "+address);
		System.out.println("PIN is: "+pin);
		System.out.println("Country is: "+country);
		System.out.println("Email ID is: "+emailid);
		System.out.println("House Number is: "+houseno);


	}
}
