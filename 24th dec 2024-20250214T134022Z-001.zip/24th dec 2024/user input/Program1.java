import java.util.Scanner;
class Program1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st Number: ");
		int x=sc.nextInt();
		System.out.println("Enter the 2nd Number: ");
		int y=sc.nextInt();
		int sum=x+y;
		System.out.println("Sum of "+x+" and "+y+" is: "+sum);
	}
}
