import java.util.Scanner;
class Program4
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s=sc.next();
		System.out.println("You entered: "+s);
	}
}
