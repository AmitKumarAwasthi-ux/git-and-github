import java.util.Scanner;
class Program3
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the boolean value: ");
		boolean b=sc.nextBoolean();
		System.out.println("You entered: "+b);
	}
}
