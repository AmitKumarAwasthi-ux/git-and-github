import java.util.Scanner;
class Case1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name: ");
		String name=sc.nextLine();
		System.out.println("Enter Age: ");
		int age=sc.nextInt();
		System.out.println("Enter Weight: ");
		double weight=sc.nextDouble();
		System.out.println("====Entered Details are Below:=======");
		System.out.println("Name is: "+name);
		System.out.println("Age is: "+age+" Years");
		System.out.println("Weight is: "+weight+" Kg");
	}
}
