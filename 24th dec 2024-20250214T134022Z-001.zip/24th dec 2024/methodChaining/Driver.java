package methodChaining;

public class Driver {
	public static void main(String[] args) {
		Employ e1=new Employ("Mohan", 123, 46547.8, "NOIDA");
		Employ e2=new Employ("Sohan", 103, 40547.8, "Delhi");
		Employ e3=new Employ("Rohan", 163, 47547.8, "GB");
		e1.getName().getId().getSalary().getAddress().getName();
		System.out.println("==========");
		e2.getId().getSalary();
		System.out.println("===============");
		e3.getAddress().getName().getSalary();
		
	}

}
