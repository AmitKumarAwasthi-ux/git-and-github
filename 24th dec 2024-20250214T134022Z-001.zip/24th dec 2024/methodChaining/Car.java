package methodChaining;

public class Car {

}
