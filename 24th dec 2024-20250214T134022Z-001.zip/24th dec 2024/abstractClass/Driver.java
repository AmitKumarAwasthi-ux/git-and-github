package abstractClass;

public class Driver {
	public static void main(String[] args) {
		Vehicle v1=new ElectricCar();
		v1.start();
		double speed=v1.drive();
		System.out.println("Speed is: "+speed);
		v1.accelerate();
		v1.stop();
		System.out.println("=================");
		Car c1=(Car)v1;
		c1.openGate();
		c1.playMusic();
		System.out.println("===================");
		ElectricCar e1=(ElectricCar)v1;
		e1.charge();
		
	}

}
