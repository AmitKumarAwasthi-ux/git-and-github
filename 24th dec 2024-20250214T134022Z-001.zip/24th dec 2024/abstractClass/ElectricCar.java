package abstractClass;

public class ElectricCar extends Car{
	
	@Override
	public void start() {
		System.out.println("Start the Electric car");
	}
	@Override
	public double drive() {
		System.out.println("drive the Electric car");
	return 45.6;
	}
	@Override
	public void openGate() {
		System.out.println("Open Gate in the Electric car");
	}
	public void charge() {
		System.out.println("Charge the Electric Car");
	}

}
