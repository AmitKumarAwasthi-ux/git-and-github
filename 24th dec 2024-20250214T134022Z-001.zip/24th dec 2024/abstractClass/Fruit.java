package abstractClass;

public abstract class Fruit {
	static int x=10;
	int y=30;
	
	static
	{
		System.out.println("This is static block");
	}
	
	{
		System.out.println("This is non-static block");
	}
	
	public static void main(String[] args) {
		Fruit v1;
	}

}
