package abstractClass;

public abstract class Vehicle extends TransportaionModes{
	
	Vehicle(){
		
	}
	
	public abstract void start();
	public abstract double drive();
	
	public void accelerate() {
		System.out.println("Accelerate the Vehicle");
	}
	public void stop() {
		System.out.println("Stop the Vehicle");
	}

}
