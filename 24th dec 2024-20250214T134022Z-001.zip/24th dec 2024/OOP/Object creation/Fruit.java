class Fruit
{
	int x=555;
	int y=666;
	public static void test(){
		System.out.println("Test Fruit");
	}
}
