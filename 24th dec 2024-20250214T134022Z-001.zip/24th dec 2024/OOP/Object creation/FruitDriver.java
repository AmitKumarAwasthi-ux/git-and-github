class FruitDriver
{
	public static void main(String[] args){
		Fruit f1=new Fruit();
		System.out.println(f1);
		System.out.println(f1.x);
		System.out.println(f1.y);
		f1.test();
	}
}
