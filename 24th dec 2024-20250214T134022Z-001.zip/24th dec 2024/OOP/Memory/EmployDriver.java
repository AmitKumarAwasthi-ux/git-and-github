class EmployDriver
{
	public static void main(String[] args){
		System.out.println("Employ Driver class starts");
		int x=12;
		System.out.println("x is: "+x);
		System.out.println(Employ.compName);
		Employ.giveBiometric();
		Employ e1=new Employ();
		Employ e2=new Employ();
		Employ e3=new Employ();
		e1.empName="Mohan";
		e1.id=123;
		e1.salary=34567.45;
		e2.empName="Sohan";
		e2.id=133;
		e2.salary=44567.45;
		e3.empName="Rohan";
		e3.id=128;
		e3.salary=30567.45;

		e2.compName="Diamond COmpany";
		e2.empName="jethalal";

		System.out.println("=======Employ1 Details==========");
		System.out.println("Object refrence is: "+e1);
		System.out.println("Company Name is: "+e1.compName);
		System.out.println("Employ Name is: "+e1.empName);
		System.out.println("ID is: "+e1.id);
		System.out.println("Salary is: "+e1.salary);
		e1.giveBiometric();
		e1.work();
		System.out.println("=======Employ2 Details==========");
		System.out.println("Object refrence is: "+e2);
		System.out.println("Company Name is: "+e2.compName);
		System.out.println("Employ Name is: "+e2.empName);
		System.out.println("ID is: "+e2.id);
		System.out.println("Salary is: "+e2.salary);
		e2.giveBiometric();
		e2.work();
		System.out.println("=======Employ3 Details==========");
		System.out.println("Object refrence is: "+e3);
		System.out.println("Company Name is: "+e3.compName);
		System.out.println("Employ Name is: "+e3.empName);
		System.out.println("ID is: "+e3.id);
		System.out.println("Salary is: "+e3.salary);
		e3.giveBiometric();
		e3.work();			
	}
}
