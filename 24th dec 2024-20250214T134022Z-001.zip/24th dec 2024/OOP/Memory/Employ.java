class Employ
{
	static String compName="ABC PVT LTD";
	String empName;
	int id;
	double salary;
	public static void giveBiometric(){
		System.out.println("EMploy Should Give Biometric");
	}
	public void work(){
		System.out.println("Employ is Working");
	}
}
