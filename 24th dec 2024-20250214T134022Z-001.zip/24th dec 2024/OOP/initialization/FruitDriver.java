class FruitDriver
{
	public static void main(String[] args){
		Fruit f1=new Fruit();
		Fruit f2=new Fruit();
		Fruit f3=new Fruit();
		f1.name="Mango";
		f1.price=110;
		f1.weight=2.3;
		f2.name="Apple";
		f2.price=180;
		f2.weight=4.1;
		System.out.println("===Fruit1 details======");
		System.out.println("Name is: "+f1.name);
		System.out.println("Price is: "+f1.price);
		System.out.println("Wight is: "+f1.weight);
		f1.test();
		f1.eat();
		System.out.println("===Fruit2 details======");
		System.out.println("Name is: "+f2.name);
		System.out.println("Price is: "+f2.price);
		System.out.println("Wight is: "+f2.weight);
		f2.test();
		f2.eat();
		System.out.println("===Fruit3 details======");
		System.out.println("Name is: "+f3.name);
		System.out.println("Price is: "+f3.price);
		System.out.println("Wight is: "+f3.weight);
		f3.test();
		f3.eat();		
	}
}
