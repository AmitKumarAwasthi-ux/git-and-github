class Fruit
{
	String name;
	int price;
	double weight;
	public void test(){
		System.out.println("Test Fruit");
	}
	public void eat(){
		System.out.println("Eat Fruit");
	}
}
