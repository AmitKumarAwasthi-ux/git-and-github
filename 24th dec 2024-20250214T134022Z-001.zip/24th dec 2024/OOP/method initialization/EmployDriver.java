class EmployDriver
{
	public static void main(String[] args){
		
		Employ e1=new Employ();
		Employ e2=new Employ();
		Employ e3=new Employ();

		e1.setValue("Mohan", 123, 325346.45);
		e2.setValue("Sohan", 122, 234344.56);
		e3.setValue("Rohan", 134, 235365.54);

		e1.getDetails();
		e2.getDetails();
		e3.getDetails();			
	}
}
