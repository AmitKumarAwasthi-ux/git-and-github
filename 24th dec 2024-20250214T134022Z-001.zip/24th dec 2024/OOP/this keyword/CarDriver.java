class CarDriver
{
	public static void main(String[] args){
		System.out.println("This is method");
		Car c1=new Car();
		Car c2=new Car();
		Car c3=new Car();
		System.out.println(c1);
		c1.test();
		System.out.println("===============");
		System.out.println(c2);
		c2.test();
		System.out.println("=================");
		System.out.println(c3);
		c3.test();


	}
}
