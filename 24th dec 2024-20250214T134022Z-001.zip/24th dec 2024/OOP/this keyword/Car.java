class Car
{
	public void test(){
		System.out.println(this);
	}
}
