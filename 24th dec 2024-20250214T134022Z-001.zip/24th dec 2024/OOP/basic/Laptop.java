class Laptop
{
	int x=555;
	int y=666;
	
}
