class Vehicle
{
	int p;
	public void demo(int p){
		System.out.println("This is demo method");
		System.out.println("Local p is: "+p);
		this.p=p;
		System.out.println("Non-static p is: "+this.p);
	}
}
