class VehicleDriver
{
	public static void main(String[] args){
		System.out.println("This is method");
		Vehicle v1=new Vehicle();
		v1.demo(300000);

	}
}
