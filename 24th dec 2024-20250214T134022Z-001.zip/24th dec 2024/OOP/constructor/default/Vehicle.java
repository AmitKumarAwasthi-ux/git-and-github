class Vehicle
{
	int x=10;
	public static void test(){
		System.out.println("static Test method");
	}
	Vehicle(int p, double q)
	{
	}
	public void drive(){
		System.out.println("non-static Drive method");
	}
	double y=34.5;
}
