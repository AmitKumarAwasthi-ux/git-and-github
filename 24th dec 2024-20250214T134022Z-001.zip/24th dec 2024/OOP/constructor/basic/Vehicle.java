class Vehicle
{
	int x=10;
	Vehicle(){
		System.out.println("Vehicle Constructor");
	}
	public static void test(){
		System.out.println("static Test method");
	}
	public void drive(){
		System.out.println("non-static Drive method");
	}

}
