class VehicleDriver
{
	public static void main(String[] args){
		Vehicle.test();
		Vehicle v1=new Vehicle();
		v1.drive();
	}
}
