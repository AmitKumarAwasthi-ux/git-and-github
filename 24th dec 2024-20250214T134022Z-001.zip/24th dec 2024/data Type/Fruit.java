class Fruit
{
		
}
