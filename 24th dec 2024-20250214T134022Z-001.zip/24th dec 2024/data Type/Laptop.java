class Laptop
{
		
}
