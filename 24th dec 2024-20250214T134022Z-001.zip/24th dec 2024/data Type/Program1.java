class Program1
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm1");
		int x;
		String s;
		Employ e;
		Laptop l;
		Fruit f;
	}
}
