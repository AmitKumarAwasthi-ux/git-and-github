class Employ
{
	String name;
	int eid;
	double salary;
	String address;		
}
