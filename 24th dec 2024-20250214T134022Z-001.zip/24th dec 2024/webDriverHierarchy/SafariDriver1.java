package webDriverHierarchy;

public class SafariDriver1 extends RemoteWebDriver1{

}
