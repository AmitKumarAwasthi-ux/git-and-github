package webDriverHierarchy;

public class RemoteWebDriver1 implements WebDriver1, JavaScriptExecutor1, TakeScreenshot1{
	@Override
	public void findElement() {
		System.out.println("find element is implemented");
	}
	@Override
	public void get() {
		System.out.println("get is implemented");
	}
	@Override
	public void executeScript() {
		System.out.println("executeScript is implemented");
	}
	@Override
	public void getScreenshot() {
		System.out.println("GetScreenshot is implemented");
	}
}
