package webDriverHierarchy;

public class FirefoxDriver1 extends RemoteWebDriver1{

}
