package webDriverHierarchy;

public interface TakeScreenshot1 {
	
	public void getScreenshot();

}
