package webDriverHierarchy;

public class ChromeDriver1 extends RemoteWebDriver1{

}
