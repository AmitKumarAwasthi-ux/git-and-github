package webDriverHierarchy;

public interface SearchContext1 {
	public void findElement();
	default void test() {
		System.out.println("default test method");
		start();
	}
	default void demo() {
		System.out.println("default demo method");
		start();
	}
	default void drive() {
		System.out.println("default test method");
		start();
	}
	private void start() {
		System.out.println("start method!!");
	}

}
