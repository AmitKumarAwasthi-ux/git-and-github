package webDriverHierarchy;

public class Driver {
	public static void main(String[] args) {
		WebDriver1 wd=new FirefoxDriver1();
		TakeScreenshot1 ts=(TakeScreenshot1)wd;
		ts.getScreenshot();
		System.out.println("================");
		FirefoxDriver1 fd=(FirefoxDriver1)wd;
		fd.findElement();
		fd.get();
		fd.executeScript();
		fd.getScreenshot();
		fd.test();
	}

}
