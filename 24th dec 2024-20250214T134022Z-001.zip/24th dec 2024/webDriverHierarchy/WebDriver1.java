package webDriverHierarchy;

public interface WebDriver1 extends SearchContext1 {
	
	public void get();

}
