/** This class is being
* designed to execute different operations 
* on Vehicle */



public class Vehicle
{
	//This is main method

	/* This main method os being
	   designed to execute vehicle 
	   related actions */

	public static void main(String[] args)
	{
		System.out.println("This is Vehicle class");
	}
	/** This method is
	* designed to start
	* Vehicle */


	public static void start()
	{
		System.out.println("Start vehicle");
	}
	/** This method is
	* designed to stop
	* Vehicle */

	public void stop()
	{
		System.out.println("Stop vehicle");
	}

}