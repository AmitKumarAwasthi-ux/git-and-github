class Program1
{
	public static void main(String[] args)
	{
		System.out.println("Java Progarm");
		System.out.println("Java Progarm".length());	
		System.out.println("Java Progarm".toUpperCase());
		System.out.println("Java Progarm".toLowerCase());
		System.out.println("Java Progarm".charAt(6));
			
	}
}
