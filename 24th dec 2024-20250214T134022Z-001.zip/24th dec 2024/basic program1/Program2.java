class Program2
{
	public static void main(String[] args)
	{
		String s1="Java Progarm";
		System.out.println(s1);
		System.out.println(s1.length());	
		System.out.println(s1.toUpperCase());
		System.out.println(s1.toLowerCase());
		System.out.println(s1.charAt(6));
			
	}
}
