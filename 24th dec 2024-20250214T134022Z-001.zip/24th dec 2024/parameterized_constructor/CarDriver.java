package parameterized_constructor;

public class CarDriver {
	public static void main(String[] args) {
		Car c1=new Car("TATA", 3543656, "White");
		Car c2=new Car("HONDA", 4543656, "Red");
		Car c3=new Car("Audi", 7543656, "Black");
		Car c4=new Car();
		Car c5=new Car("Audi");
		Car c6=new Car("BMW", 4758778);
		
		c1.getDetails();
		c2.getDetails();
		c3.getDetails();
		c4.getDetails();
		c5.getDetails();
		c6.getDetails();
	}

}
