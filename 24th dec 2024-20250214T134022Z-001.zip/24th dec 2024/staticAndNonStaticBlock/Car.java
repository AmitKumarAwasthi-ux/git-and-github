package staticAndNonStaticBlock;

public class Car {
	String name;
	{
		System.out.println("Non-static block-1");
		name="TATA";
	}
	public static void main(String[] args) {
		System.out.println("main starts");
		Car c1=new Car();
		System.out.println(c1.name);
		System.out.println("===============");
		Car c2=new Car();
		System.out.println(c2.name);
		System.out.println("===============");
		Car c3=new Car();
		System.out.println(c3.name);
		System.out.println("===============");
	}
	static{
		System.out.println("This is static block");
	}
	{
		System.out.println("Non-static block-2");
	}

}
