package staticAndNonStaticBlock;

public class Program1 {
	static int x;
	static{
		System.out.println("This is static block-1");
		x=45;
	}
	
	public static void main(String[] args) {
		System.out.println("Main method");
		System.out.println("x is: "+x);
		
	}
	static{
		System.out.println("This is static block-2");
	}

}
