package staticAndNonStaticBlock;

public class Vehicle {
	final static int x=56;
	static {
		//x=67;
	}
	public static void main(String[] args) {
		System.out.println("x is: "+x);
	}

}
