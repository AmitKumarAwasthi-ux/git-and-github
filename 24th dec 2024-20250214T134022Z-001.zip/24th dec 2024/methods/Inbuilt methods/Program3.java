class Program3
{
	public static void main(String[] args){
		double num=Math.random();
		System.out.println("Random Number is: "+num);
	}
}
