//Generate random number
import java.util.Random;
class Program6
{
	public static void main(String[] args){
		Random r1=new Random();
		System.out.println("Random Number is: "+r1.nextInt());
		System.out.println("Random Number is: "+r1.nextInt(1000));

	}
}
