//Generate random number in a range
import java.util.Random;
class Program7
{
	public static void main(String[] args){
		Random r1=new Random();
		int min=50, max=80;
		int num=min+r1.nextInt(max-min);
		System.out.println("Random Number is: "+num);

	}
}
