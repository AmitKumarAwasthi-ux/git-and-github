class Program2
{
	public static void main(String[] args){
		System.out.println(Math.PI);
		System.out.println(Math.sqrt(145));
		System.out.println(Math.pow(7,3));
		System.out.println(Math.min(14,5));
		System.out.println(Math.max(14,5));
		System.out.println(Math.ceil(14.4));	
		System.out.println(Math.floor(14.4));
		System.out.println(Math.abs(14-25));
		System.out.println(Math.round(14.3));
		System.out.println(Math.round(14.7));
		System.out.println(Math.round(14.5));
	}
}
