//Generate 4-digit OTP
class Program5
{
	public static void main(String[] args){
		int n1=999;
		int n2=9999;
		int num=n1+(int)(Math.random()*(n2-n1))+1;
		System.out.println("Random Number is: "+num);
	}
}
