class Program1
{
	public static void main(String[] args){
		System.out.println("This is Program1 main method");
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.BYTES);


	}
}
