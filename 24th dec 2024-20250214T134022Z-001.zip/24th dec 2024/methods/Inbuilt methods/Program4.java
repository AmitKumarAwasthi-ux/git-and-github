//One Digit random Number
class Program4
{
	public static void main(String[] args){
		int num=(int)(Math.random()*100);
		System.out.println("Random Number is: "+num);
	}
}
