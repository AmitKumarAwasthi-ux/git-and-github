class Program3
{
	public static void test(){
		System.out.println("This is tes method");
		System.out.println(demo());
	}

	public static void main(String[] args){
		System.out.println("This is main method");
		test();
	}
	public static int demo(){
		System.out.println("This is demo method");
		
	return 50;
	}
}
