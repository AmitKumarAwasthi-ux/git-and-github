class Program2
{
	public static void main(String[] args){
		System.out.println(demo());
		System.out.println("============");
		System.out.println("Return value is: "+demo());
		System.out.println("============");
		int result=demo();
		System.out.println("result is: "+result);

	}
	public static int demo(){
		System.out.println("This is demo method");
	return 50;
	}
}
