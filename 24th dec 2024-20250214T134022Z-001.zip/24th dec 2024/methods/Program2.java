class Program2
{
	public static void test(){
		System.out.println("This is Program2 test method");
		System.out.println("test ends");
	}
	public static void main(String[] args){
		System.out.println("This is Program2 main method");
		demo();
		System.out.println("====Main Ends=====");
	}
	public static void demo(){
		System.out.println("This is Program2 demo method");
		test();
		System.out.println("demo ends");
	}
}
