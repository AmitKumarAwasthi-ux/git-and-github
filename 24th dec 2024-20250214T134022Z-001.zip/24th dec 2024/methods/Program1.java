class Program1
{
	public static void test(){
		System.out.println("This is Program1 test method");
	}
	
	public static void demo(){
		System.out.println("This is Program1 demo method");
	}
}
