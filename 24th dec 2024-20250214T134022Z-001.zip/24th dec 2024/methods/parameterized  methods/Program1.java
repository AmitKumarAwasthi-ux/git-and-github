class Program1
{
	public static void addThreeNumbers(int x, int y, int z){
		int sum=x+y+z;
		System.out.println("sum of "+x+","+y+","+z+" is: "+sum);
	}

	public static void main(String[] args){
		int n1=23;
		int n2=45;
		addTwoNumbers(n1,n2);
		addTwoNumbers(18, 36);
		addThreeNumbers(n1, n2, 100);

	}
	
	public static void addTwoNumbers(int x, int y){
		int sum=x+y;
		System.out.println("sum of "+x+","+y+" is: "+sum);
	}
}
