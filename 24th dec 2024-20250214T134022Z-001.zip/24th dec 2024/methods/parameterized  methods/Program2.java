class Program2
{
	public static void main(String[] args){
		int n1=23;
		int n2=45;
		int sum=addTwoNumbers(n1,n2);
		System.out.println("From main sum of "+n1+","+n2+" is: "+sum);
	}
	
	public static int addTwoNumbers(int x, int y){
		int sum=x+y;
		System.out.println("sum of "+x+","+y+" is: "+sum);
	return sum;
	}
}
