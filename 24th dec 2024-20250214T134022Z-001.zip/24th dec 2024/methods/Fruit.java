class Fruit
{
	public static void test(){
		System.out.println("Test the fruit");
	}

	public void eat(){
		System.out.println("Eat the fruit");
	}
}
