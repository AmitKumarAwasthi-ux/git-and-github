class Program1
{
	public static void test(){
		System.out.println("This is Program1 test method");
	}
	synchronized strictfp static final public  void main(String[] args){
		System.out.println("This is Program1 main method");
	}

	public static int demo(int n){
		System.out.println("This is Program1 demo method");
	return 10;
	}
}
