class Driver
{
	public static void main(String[] args){
		System.out.println("This is Driver class main method");
		Fruit.test();
		Fruit f1=new Fruit();
		f1.eat();
		System.out.println("====Main Ends=====");
	}
}
