package interfacePart;

public interface Vehicle {
	int x=30;
	
	public void start() ;
	public void stop() ;
	default void test() {
		System.out.println("test vehicle");
	}

}
