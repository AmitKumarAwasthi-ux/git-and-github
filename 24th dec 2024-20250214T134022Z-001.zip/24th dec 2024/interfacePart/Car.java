package interfacePart;

public interface Car extends Vehicle{
	
	public void playMusic();


}
