package interfacePart;

public class ElectricCar implements Car{
	
	@Override
	public void start() {
		System.out.println("Start electric car");
	}
	@Override
	public void stop() {
		System.out.println("Stop electric car");
	}
	@Override
	public void playMusic() {
		System.out.println("playMusic electric car");
	}
	public void charge() {
		System.out.println("charge electric car");
	}
	

}
