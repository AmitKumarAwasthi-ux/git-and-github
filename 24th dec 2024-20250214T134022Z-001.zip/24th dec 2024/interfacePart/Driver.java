package interfacePart;

public class Driver {
	public static void main(String[] args) {
		Vehicle v1=new ElectricCar();
		v1.start();
		v1.stop();
		System.out.println("=======");
		Car c1=(Car)v1;
		c1.playMusic();
		System.out.println("==========");
		ElectricCar e1=(ElectricCar)v1;
		e1.charge();
	}

}
