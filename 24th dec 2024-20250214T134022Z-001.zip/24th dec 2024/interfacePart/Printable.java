package interfacePart;
@FunctionalInterface
public interface Printable {
	
	public void printPage();
	
	
	public static void test() {
		System.out.println("test method");
	}
	default void drive() {
		System.out.println("default type method");
	}
	

}
