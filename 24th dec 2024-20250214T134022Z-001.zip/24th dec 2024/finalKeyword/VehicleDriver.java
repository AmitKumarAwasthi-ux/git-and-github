package finalKeyword;

public class VehicleDriver {
	public static void main(String[] args) {
		Vehicle v1=new Vehicle("Up12bfg34");
		Vehicle v2=new Vehicle("Up23bfg34");
		v1.price=456578.67;
		
		v1.getDetails();
		v2.getDetails();
	}

}
