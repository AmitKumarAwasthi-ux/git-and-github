package finalKeyword;

public abstract class Laptop {
	
	
	public abstract void demo() ;

}
