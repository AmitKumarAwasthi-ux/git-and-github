package finalKeyword;

public class Vehicle {
	final static String brand="TATA";
	double price;
	final String carno;
	String color;
	Vehicle(String carno){
		this.carno=carno;
	}
	Vehicle(double price, String color, String carno){
		this.price=price;
		this.color=color;
		this.carno=carno;
	}
	public void getDetails() {
		System.out.println(price+" "+carno+" "+color);
	}
}
