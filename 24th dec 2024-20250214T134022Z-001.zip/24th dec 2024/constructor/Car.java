package constructor;

public class Car {
	static int count=0;
	Car(){
		count++;
		System.out.println("Car Object "+count+" is Created");
	}
	Car(int p){
		count++;
		System.out.println("Car Object "+count+" is Created");
	}
	Car(String name){
		count++;
		System.out.println("Car Object "+count+" is Created");
	}

}
