package constructor;

public class CarDriver {
	public static void main(String[] args) {
		Car c1=new Car();
		Car c2=new Car();
		Car c3=new Car();
		Car c4=new Car();
		Car c5=new Car();
		Car c6=new Car();
		Car c7=new Car();
		Car c8=new Car();
		Car c9=new Car();
		Car c10=new Car();
		Car c11=new Car(12);
		Car c12=new Car("TATA");
		System.out.println("Total Car Object created is: "+Car.count);
	}

}
