package vehicle;
import tyre.MRF;
public class Bike {
	public static void main(String[] args) {
		System.out.println("This is Bike class");
		System.out.println("a is: "+MRF.a);
		MRF.test();
		
	}

}
