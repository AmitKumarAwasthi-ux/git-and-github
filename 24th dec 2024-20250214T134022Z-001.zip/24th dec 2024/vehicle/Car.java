package vehicle;
import tyre.MRF;
public class Car extends MRF{
	public static void main(String[] args) {
		System.out.println("This is Car class");
		System.out.println("a is: "+MRF.a);
		MRF.test();
		System.out.println("b is: "+MRF.b);
		MRF.demo();
	
	}

}
