package object_class;

public class Employ {
	String name;
	int id;
	double salary;
	Employ(){
		
	}
	Employ(String name, int id, double salary){
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	@Override
	public String toString() {
	return "Name is: "+name+"\tID is: "+id+"\tSalary is: "+salary;
	}
	@Override
	public int hashCode() {
	return id;
	}
	@Override
	public boolean equals(Object obj) {
		Employ e=(Employ)obj;
	return this.name.equals(e.name) && 
			this.id==e.id && 
			this.salary==e.salary;
	}
	public void finalize() {
		System.out.println("close system connection");
		System.out.println("close network connection");
		System.out.println("close database connection");
		System.out.println("======================");
	}

}




