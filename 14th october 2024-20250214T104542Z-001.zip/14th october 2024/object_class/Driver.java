package object_class;

public class Driver {
	public static void main(String[] args) {
		String s1=new String("mohan");
		String s2=new String("mohan");
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println("=============================");
		Employ e1=new Employ("Mohan", 120, 23456.1);
		Employ e2=new Employ("Sohan", 125, 20056.1);
		Employ e3=new Employ("Mohan", 120, 23456.1);
		Employ e4=new Employ("Mohan", 120, 23456.1);
		System.out.println("=========toString()==========");
		System.out.println(e1);
		System.out.println(e1.toString());
		System.out.println("===============");
		System.out.println(e2);
		System.out.println(e2.toString());
		System.out.println("===============");
		System.out.println(e3);
		System.out.println(e3.toString());
		System.out.println("===========hashCode()============");
		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
		System.out.println(e3.hashCode());
		System.out.println("=======equals()====================");
		System.out.println(e1==e2);
		System.out.println(e1==e3);
		System.out.println("============");
		System.out.println(e1.equals(e2));
		System.out.println(e1.equals(e3));
		System.out.println(e1.equals(e4));
		System.out.println("=======fianlize()====================");
		e1=null;
		e2=null;
		System.gc();
		
	}

}
