package weapon_project;

public class Gun extends Weapon{
	
	@Override
	public void use() {
		System.out.println("Use the Gun");
		System.out.println("Load the Gun");
		System.out.println("AIm at Enemy");
		System.out.println("Fire....");
	}

}
