package weapon_project;

public class Bomb extends Weapon{
	
	@Override
	public void use() {
		System.out.println("Use the Bomb");
		System.out.println("Upin the Bomb");
		System.out.println("Aim ate enemy");
		System.out.println("Throw it....");
		System.out.println("BOOOOM.....BOOOOMMM");
	}

}
