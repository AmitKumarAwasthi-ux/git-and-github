package weapon_project;

public class Weapon {
	
	public void use() {
		System.out.println();
	}

}
