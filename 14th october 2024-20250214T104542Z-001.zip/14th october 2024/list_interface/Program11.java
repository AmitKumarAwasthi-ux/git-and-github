package list_interface;

import java.util.ArrayList;
import java.util.*;
import java.util.ListIterator;

public class Program11 {
	public static void main(String[] args) {
		Set<Integer> s1=new LinkedHashSet<>();
		s1.add(44);
		s1.add(66);
		s1.add(88);
		List<Integer> l1=new ArrayList<>(s1);
		l1.add(16);l1.add(18);l1.add(25);
		l1.add(30);l1.add(40);l1.add(48);
		ListIterator<Integer> lit=l1.listIterator();
		for(int i=0;i<l1.size();i++) {
			if(l1.get(i)%2==1)
				l1.remove(i);
		}
		System.out.println(l1);
	}

}
