package list_interface;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.ArrayList;

public class Program17 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList();
		l1.add(34);l1.add(55);
		l1.add(45);l1.add(57);
		l1.add(44);l1.add(62);
		System.out.println("Before Sorting: "+l1);
		l1.sort(Comparator.reverseOrder());
		System.out.println("After Sorting: "+l1);
	}

}
