package list_interface;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Program10 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(16);l1.add(18);l1.add(25);
		l1.add(30);l1.add(40);l1.add(48);
		for(int x:l1) {
			if(x%2==1)
				l1.remove((Object)x);//concurrentmodificationexception
		}
		System.out.println(l1);
	}

}
