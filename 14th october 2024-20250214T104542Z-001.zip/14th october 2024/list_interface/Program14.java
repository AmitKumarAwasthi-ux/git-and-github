package list_interface;

import java.util.LinkedList;

public class Program14 {
	public static void main(String[] args) {
		LinkedList<Integer> l1=new LinkedList();
		l1.add(34);l1.add(55);
		l1.add(45);l1.add(57);
		l1.add(44);l1.add(62);
		while(!l1.isEmpty()) {
			System.out.println(l1.removeLast());
		}
	}

}
