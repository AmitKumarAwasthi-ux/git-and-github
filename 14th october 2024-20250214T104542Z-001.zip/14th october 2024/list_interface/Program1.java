package list_interface;
import java.util.*;
public class Program1 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(45);l1.add(56);
		l1.add(33);l1.add(43);l1.add(60);
		for(int i=0;i<l1.size();i++)
			System.out.println(l1.get(i));
		
	}

}
