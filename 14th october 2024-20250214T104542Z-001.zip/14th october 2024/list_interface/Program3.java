package list_interface;
import java.util.ArrayList;
import java.util.*;
public class Program3 {
		public static void main(String[] args) {
			List<Integer> l1=new ArrayList<>();
			l1.add(23);l1.add(45);l1.add(56);
			l1.add(33);l1.add(43);l1.add(60);
			ListIterator<Integer> lit=l1.listIterator();
			while(lit.hasNext())
				System.out.println(lit.next());
			
	}

}
