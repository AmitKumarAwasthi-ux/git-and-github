package list_interface;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Program9 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(16);l1.add(18);l1.add(25);
		l1.add(30);l1.add(40);l1.add(48);
		ListIterator<Integer> lit=l1.listIterator();
		while(lit.hasNext()) {
			if(lit.next()%2==1)
				lit.add(100);
		}
		System.out.println(l1);
	}

}
