package list_interface;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Program4 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(45);l1.add(56);
		l1.add(33);l1.add(43);l1.add(60);
		ListIterator<Integer> lit=l1.listIterator();
		int sum=0;
		while(lit.hasNext())
			sum=sum+lit.next();
		System.out.println("SUm is: "+sum);
		
}

}
