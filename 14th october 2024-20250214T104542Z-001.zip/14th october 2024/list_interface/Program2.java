package list_interface;
import java.util.ArrayList;
import java.util.List;
public class Program2 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(45);l1.add(56);
		l1.add(33);l1.add(43);l1.add(60);
		int sum=0; 
		for(int x:l1)
			sum=sum+x;
		System.out.println("Total sum is: "+sum);
	}

}
