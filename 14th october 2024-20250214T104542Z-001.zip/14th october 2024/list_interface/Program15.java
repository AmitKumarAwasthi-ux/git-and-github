package list_interface;

import java.util.*;

public class Program15 {
	public static void main(String[] args) {
		LinkedList<Integer> l1=new LinkedList();
		l1.add(34);l1.add(55);
		l1.add(45);l1.add(57);
		l1.add(44);l1.add(62);
		Iterator itr=l1.descendingIterator();
		while(itr.hasNext())
			System.out.println(itr.next());
			
	}

}
