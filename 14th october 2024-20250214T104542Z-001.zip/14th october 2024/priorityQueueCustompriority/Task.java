package priorityQueueCustompriority;

public class Task {
	String name;
	int priority;
	double expense;
	Task(){
		
	}
	Task(String name, int priority, double expense){
		this.name=name;
		this.priority=priority;
		this.expense=expense;
	}
	public String toString() {
	return "task{Name: "+name+" priority: "+priority+" expense: "+expense+"}";
	}

}
