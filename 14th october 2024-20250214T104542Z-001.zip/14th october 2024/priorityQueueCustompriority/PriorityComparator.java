package priorityQueueCustompriority;
import java.util.*;
public class PriorityComparator implements Comparator<Task>{
	
	public int compare(Task t1, Task t2) {
	return t1.priority-t2.priority;
	}

}
