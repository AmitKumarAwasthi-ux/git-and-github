package priorityQueueCustompriority;
import java.util.*;
public class TaskDriver {
	public static void main(String[] args) {
		Queue<Task> q1=new PriorityQueue<>(new PriorityComparator());
		q1.add(new Task("Implementation", 3,234455.34));
		q1.add(new Task("Planning", 1,204455.34));
		q1.add(new Task("Documentation", 10,214455.34));
		while(!q1.isEmpty()) {
			System.out.println(q1.poll());
		}
		
	}

}
