package priorityQueueCustompriority;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.*;

public class TaskDriver1 {
	public static void main(String[] args) {
		Scanner sc;
		//Queue<Task> q1=new PriorityQueue<>(Comparator.comparingInt( (t) -> t.priority   ));
		Queue<Task> q1=new PriorityQueue<>(Comparator.comparingDouble( (t) -> t.expense   ));                   
		q1.add(new Task("Implementation", 3,234455.34));
		q1.add(new Task("Planning", 1,204455.34));
		q1.add(new Task("Documentation", 10,214455.34));
		while(!q1.isEmpty()) {
			System.out.println(q1.poll());
		}
	}

}
