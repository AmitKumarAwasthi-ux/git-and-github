package fileHandling;

import java.io.File;
import java.io.IOException;

public class Program3 {
	public static void main(String[] args) {
		String filedetails="f:\\";
		File f1=new File(filedetails);
		try {
			f1.createNewFile();
			System.out.println("FIle is created");
			String[] s=f1.list();
			for(String k:s)
				System.out.println(k);

		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.out.println("File is NOT Created!!");
		}
		System.out.println("=======Program Ends=======");
	}

}
