package fileHandling;

import java.io.File;
import java.io.FileWriter;
import java.io.*;
import java.util.Scanner;

public class WriteToFile4 {
	public static void main(String[] args) {
		String fileDetails="src\\fileHandling\\userDetails1.txt";
		File file=new File(fileDetails);
		try(FileWriter fw=new FileWriter(file, true);
			BufferedWriter bfw=new BufferedWriter(fw);
			Scanner sc=new Scanner(System.in)) {
			
			System.out.println("ENter Name: ");
			String name=sc.nextLine();
			System.out.println("Enter EmailId: ");
			String emailid=sc.nextLine();
			System.out.println("Enter the Mobile Number: ");
			long mobno=sc.nextLong();
			bfw.write("Name is: "+name+"\n");
			bfw.write("EmailId is: "+emailid+"\n");
			bfw.write("Mobile Number is: "+mobno+"\n");
			bfw.write("===================\n");
			System.out.println("File writing is Successfully completed");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
