package fileHandling;
import java.io.*;
public class Program1 {
	public static void main(String[] args) {
		String filedetails="f:\\abcde\\abc.txt";
		File f1=new File(filedetails);
		try {
			f1.createNewFile();
			System.out.println("FIle is created");
		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.out.println("File is NOT Created!!");
		}
		System.out.println("=======Program Ends=======");
	}

}
