package fileHandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile2 {
	public static void main(String[] args) {
		String fileDetails="src\\fileHandling\\xyz.txt";
		File file=new File(fileDetails);
		try {
			FileWriter fw=new FileWriter(file,true);
			fw.write(66);
			fw.write("\nMohan is here\n");
			char[] x= {97, 98, 99, 100, 'e', 'f'};
			fw.write(x);
			fw.write("\n=========================\n");
			//fw.close();
			fw.flush();
			System.out.println("File writing is Successfully completed");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("========Program Ends==========");
	}

}
