package fileHandling;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class WriteToFile3 {
	public static void main(String[] args) {
		String fileDetails="src\\fileHandling\\userDetails.txt";
		File file=new File(fileDetails);
		try(FileWriter fw=new FileWriter(file, true);
			Scanner sc=new Scanner(System.in)) {
			System.out.println("ENter Name: ");
			String name=sc.nextLine();
			System.out.println("Enter EmailId: ");
			String emailid=sc.nextLine();
			System.out.println("Enter the Mobile Number: ");
			long mobno=sc.nextLong();
			fw.write("Name is: "+name+"\n");
			fw.write("EmailId is: "+emailid+"\n");
			fw.write("Mobile Number is: "+mobno+"\n");
			fw.write("===================\n");
			System.out.println("File writing is Successfully completed");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
	}

}
