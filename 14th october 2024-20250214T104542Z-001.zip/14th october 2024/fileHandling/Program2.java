package fileHandling;

import java.io.File;
import java.io.IOException;

public class Program2 {
	public static void main(String[] args) {
		String filedetails="f:\\abc.txt";
		File f1=new File(filedetails);
		try {
			f1.createNewFile();
			System.out.println("FIle is created");
			System.out.println(f1.getName());
			System.out.println(f1.length());
			f1.setWritable(false);
			System.out.println(f1.canRead());
			System.out.println(f1.canWrite());
		} catch (IOException e) {
			System.out.println(e.getMessage());
			System.out.println("File is NOT Created!!");
		}
		System.out.println("=======Program Ends=======");
	}

}
