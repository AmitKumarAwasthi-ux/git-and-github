package fileHandling;

import java.io.File;
import java.io.FileOutputStream;
import java.io.*;
import java.util.Scanner;

public class ReadFile1 {
	public static void main(String[] args) {
		String fileDetails="src\\fileHandling\\Program1.java";
		File file=new File(fileDetails);
		try(FileReader fr=new FileReader(file)){
		
			//int x=fr.read();
			//System.out.println(x);
			//System.out.println((char)x);
			int x=fr.read();
			while(x!=-1) {
				System.out.print((char)x);
			x=fr.read();
			}
			System.out.println("File Reading is Successfully completed");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
