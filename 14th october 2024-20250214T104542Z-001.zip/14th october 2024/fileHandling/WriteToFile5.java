package fileHandling;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.util.Scanner;

public class WriteToFile5 {
	public static void main(String[] args) {
		String fileDetails="src\\fileHandling\\userDetails3.txt";
		File file=new File(fileDetails);
		try(FileOutputStream fos=new FileOutputStream(file, true);
			Scanner sc=new Scanner(System.in)) {
			//fos.write(66);
			//fos.write("abcde".getBytes());
			System.out.println("ENter Name: ");
			String name=sc.nextLine();
			System.out.println("Enter EmailId: ");
			String emailid=sc.nextLine();
			System.out.println("Enter the Mobile Number: ");
			long mobno=sc.nextLong();
			String nameDetails="Name is: "+name+"\n";
			fos.write(nameDetails.getBytes());
			fos.write(("EmailId is: "+emailid+"\n").getBytes());
			fos.write(("Mobile Number is: "+mobno+"\n").getBytes());
			fos.write("===================\n".getBytes());
			System.out.println("File writing is Successfully completed");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
