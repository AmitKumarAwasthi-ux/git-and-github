package abstract_class;
public abstract class Vehicle {
	static String brand="TATA";
	String name;
	int price;
	Vehicle(){
		
	}
	Vehicle(String name, int price){
		this.name=name;
		this.price=price;
	}
	public abstract void start();
	public abstract int drive();
	
	public void accelerate() {
		System.out.println("Drive Vehicle");
	}
	public void stop() {
		System.out.println("Stop Vehicle");
	}

}
