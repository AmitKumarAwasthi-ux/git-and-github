package abstract_class;

public class PetrolCar{
	

}
