package abstract_class;
public class ElectricCar extends Car{
	int volt;
	ElectricCar(){
		
	}
	ElectricCar(String name, int price, int hp, int volt){
		super(name, price, hp);
		this.volt=volt;
	}
	public void start() {
		System.out.println("Start the Electriccar");
	}
	public int drive() {
		System.out.println("drive the Electriccar");
	return 50;
	}
	public void openGate() {
		System.out.println("Open gate in ElectricCar");
	}
	

}
