package abstract_class;

public class Driver {
	public static void main(String[] args) {
		Vehicle v1=new ElectricCar("TATA EV11x", 235366, 150, 450);
		v1.start();
		v1.drive();
		v1.accelerate();
		v1.stop();
		Car c1=(Car)v1;
		c1.openGate();
		c1.playMusic();
		
	}

}
