class Program4
{
	public static void main(String[] args)
	{
		byte x=(byte)428;
		System.out.println(x);
	}

}






