class Program2
{
	public static void main(String[] args)
	{
		byte x=(byte)128;
		System.out.println(x);
	}

}






