class Program1
{
	public static void main(String[] args)
	{
		byte x=127;
		System.out.println(x);
		byte y=-128;
		System.out.println(y);
	}

}






