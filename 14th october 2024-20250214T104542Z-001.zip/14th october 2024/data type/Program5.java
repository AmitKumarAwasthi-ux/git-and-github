class Program5
{
	public static void main(String[] args)
	{
		byte x=(byte)1000;
		short y=1000;
		System.out.println(x);
		System.out.println(y);

	}

}






