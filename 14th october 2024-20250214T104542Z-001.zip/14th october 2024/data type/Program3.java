class Program3
{
	public static void main(String[] args)
	{
		byte x=(byte)300;
		System.out.println(x);
	}

}






