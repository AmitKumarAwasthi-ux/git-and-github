package static_nonstatic_block;
public class Program1 {
	static int x;
	static
	{
		System.out.println("This is Static block-1");
		System.out.println("x is: "+x);
		x=34;
	}
	
	public static void main(String[] args) {
		System.out.println("This is main method");
	}
	
	static
	{
		System.out.println("This is Static block-2");
		System.out.println("x is: "+x);
	}
}
