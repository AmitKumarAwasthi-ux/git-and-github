package static_nonstatic_block;

public class Car {
	int x;

	{
		System.out.println("This is non-static block-1");
		System.out.println(x);
		x=45;
	}
	static {
		System.out.println("This is static block-1");
	}
	public static void main(String[] args) {
		System.out.println("This is main method");
		Car c1=new Car();
		System.out.println("===============");
		Car c2=new Car();
		System.out.println("===============");
		Car c3=new Car();
	}
	{
		System.out.println("This is non-static block-2");
		System.out.println(x);
	}

}
