package comparable_sorting;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class EmployDriver {
	public static void main(String[] args) {
		List<Employ> l1=new ArrayList<>();
		Employ e1=new Employ("mohan",123, 34643.56);
		l1.add(e1);
		l1.add(new Employ("john", 122, 46547.45));
		l1.add(new Employ("sohan", 132, 46547.45));
		l1.add(new Employ("jack", 102, 46547.45));
		l1.add(new Employ("john2", 312, 32547.45));
		System.out.println("=====Before Sorting==========");
		for(Employ x:l1)
			System.out.println(x);
		System.out.println("=====Sort on Salary===============");
		Collections.sort(l1);
		for(Employ x:l1)
			System.out.println(x);
	}

}
