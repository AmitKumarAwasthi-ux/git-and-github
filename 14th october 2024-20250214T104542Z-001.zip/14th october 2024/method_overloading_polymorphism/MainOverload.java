package method_overloading_polymorphism; 
public class MainOverload {
	public static void main(String args) {
		System.out.println("main with String");
	}
	public static void main(int args) {
		System.out.println("main with int");
	}
	public static void main(String[] args) {
		System.out.println("main with String[]");
		main(12);
		main("abc");
		main(12.9);
	}
	public static void main(double args) {
		System.out.println("main with double");
	}
	public static void main(char args) {
		System.out.println("main with char");
	}
}
