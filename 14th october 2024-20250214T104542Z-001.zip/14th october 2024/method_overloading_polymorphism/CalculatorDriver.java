package method_overloading_polymorphism;

public class CalculatorDriver {
	public static void main(String[] args) {
		System.out.println(56+50.8);
		
		Calculator.add(12, 45.6);
		System.out.println("==================");
		Calculator.add(12, 44);
		System.out.println("==================");
		Calculator.add(23.5, 23);
		System.out.println("==============");
		Calculator.add(34, 55.8, 34);
	}

}
