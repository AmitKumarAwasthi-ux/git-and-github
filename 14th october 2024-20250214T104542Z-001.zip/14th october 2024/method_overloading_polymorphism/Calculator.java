package method_overloading_polymorphism;

public class Calculator {
	public static void add(int x, int y) {
		System.out.println("int, int arg add method");
		System.out.println("sum is: "+(x+y));
	}
	public static void add(int x, double y) {
		System.out.println("int, double arg add method");
		System.out.println("sum is: "+(x+y));
	}
	public static void add(double x, int y) {
		System.out.println("double, int arg add method");
		System.out.println("sum is: "+(x+y));
	}
	public static void add(double x, double y) {
		System.out.println("double, double arg add method");
		System.out.println("sum is: "+(x+y));
	}
	public static void add(int x, double y, double z) {
		System.out.println("int, double, double arg add method");
		System.out.println("sum is: "+(x+y+z));
	}
	public static void add(int x, int y, double z) {
		System.out.println("int, int, double arg add method");
		System.out.println("sum is: "+(x+y+z));
	}
	public static void add(int x, double y, int z) {
		System.out.println("int, double, int arg add method");
		System.out.println("sum is: "+(x+y+z));
	}
	public static void add(double x, int y, double z) {
		System.out.println("double,int, double arg add method");
		System.out.println("sum is: "+(x+y+z));
	}
	

}
