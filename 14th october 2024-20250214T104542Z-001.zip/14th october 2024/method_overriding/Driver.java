package method_overriding;

public class Driver {
	public static void main(String[] args) {
		Vehicle v1=new Car();
		v1.start();
	}

}
