package method_overriding;

public class Vehicle {
	
	public void start() {
		System.out.println("Start Vehicle");
	}

}
