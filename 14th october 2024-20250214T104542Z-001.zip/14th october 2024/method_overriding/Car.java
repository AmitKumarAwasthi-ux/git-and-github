package method_overriding;

public class Car extends Vehicle{
	
	public void start() {
		System.out.println("Start Car");
	}

}
