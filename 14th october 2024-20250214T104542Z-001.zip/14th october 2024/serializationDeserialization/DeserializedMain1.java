package serializationDeserialization;

import java.io.File;
import java.io.FileOutputStream;
import java.io.*;

public class DeserializedMain1 {
	public static void main(String[] args) {
		File file=new File("f:\\employdata.ser");
		try(FileInputStream fos=new FileInputStream(file);
			ObjectInputStream ois=new ObjectInputStream(fos)){
			Employ e1=(Employ)ois.readObject();
			System.out.println(e1.name+" "+e1.uid+" "+e1.pwd+" "+e1.salary);
			System.out.println("Deserialization is Successfully Completed!!");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	

}
