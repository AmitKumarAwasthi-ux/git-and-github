package serializationDeserialization;

import java.io.Serializable;

public class Employ implements Serializable{
	public static final long serialVersionUID=101L;
	String name;
	String uid;
	transient String pwd;
	double salary;
	Employ(){
		
	}
	Employ(String name, String uid, String pwd, double salary){
		this.name=name;
		this.uid=uid;
		this.pwd=pwd;
		this.salary=salary;
	}
	

}
