package serializationDeserialization;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;
public class Serializedmain2 {
	public static void main(String[] args) {
		List<Employ> l1=new ArrayList<>();
		Employ e1=new Employ("mohan", "mohan12","mohanpwd", 40657.67);
		Employ e2=new Employ("sohan", "sohan12","sohanpwd", 46657.67);
		Employ e3=new Employ("rohan", "rohan12","rohanpwd", 45657.67);
		Employ e4=new Employ("john", "john12","johnpwd", 45658.67);
		l1.add(e1);l1.add(e2);l1.add(e3);l1.add(e4);
		//System.out.println("=======steps of serialization=========");
		File file=new File("f:\\employdataList.ser");
		try(FileOutputStream fos=new FileOutputStream(file);
			ObjectOutputStream oos=new ObjectOutputStream(fos)){
			oos.writeObject(l1);
			System.out.println("Seriliazation is successfully Completed!!");
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
