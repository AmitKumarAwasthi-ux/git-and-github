package serializationDeserialization;
import java.util.*;
import java.io.*;
public class SerializedMain1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name: ");
		String name1=sc.nextLine();
		System.out.println("Enter UID: ");
		String uid1=sc.nextLine();
		System.out.println("Enter Password: ");
		String pwd1=sc.nextLine();
		System.out.println("Enter Salary: ");
		double salary1=sc.nextDouble();
		Employ e1=new Employ(name1, uid1, pwd1, salary1);
		//System.out.println("=======steps of serialization=========");
		File file=new File("f:\\employdata.ser");
		try(FileOutputStream fos=new FileOutputStream(file);
			ObjectOutputStream oos=new ObjectOutputStream(fos)){
			oos.writeObject(e1);
			System.out.println("Seriliazation is successfully Completed!!");
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}

	}

}





