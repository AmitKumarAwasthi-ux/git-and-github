package serializationDeserialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.*;

public class DererializationMain2 {
	public static void main(String[] args) {
		File file=new File("f:\\employdataList.ser");
		try(FileInputStream fos=new FileInputStream(file);
			ObjectInputStream ois=new ObjectInputStream(fos)){
			Object o1=ois.readObject();
			List<Employ> e= (List<Employ>)o1;
			for(Employ x:e)
				System.out.println(x.name+"\t"+x.uid+"\t"+x.pwd+"\t"+x.salary);
			
			System.out.println("Deserialization is Successfully Completed!!");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
