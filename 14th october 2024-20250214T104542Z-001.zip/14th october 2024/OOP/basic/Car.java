class Car
{
	public static void main(String[] args)
	{
		System.out.println("Car class main method");
		int x;
		Car c;
		Laptop l;
		Fruit f;
		System.out.println("Car class ends!");
	}
}

class Laptop{
	
}






