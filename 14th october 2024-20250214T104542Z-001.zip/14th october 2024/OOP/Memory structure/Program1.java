class Program1
{
	
	public static void main(String[] args){
		System.out.println("this is main method");
		test();
	}
	public static  void test(){
		System.out.println("this is test method");
		test();
	}
}







