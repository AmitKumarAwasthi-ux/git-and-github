class Employ
{
	static String comp_name="ABC Pvt Ltd";
	String name;
	int id;
	public static  void giveBiometric(){
		System.out.println("Employ should give Biometric");
	}
	public void work(){
		System.out.println("Employ is working");
	}
}







