class EmployDriver
{
	public static void main(String[] args)
	{
		System.out.println("main STarts");
		Employ e1=new Employ();
		Employ e2=new Employ();
		Employ e3=new Employ();
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e3);
		System.out.println(Employ.comp_name);
		Employ.giveBiometric();
		e2.name="John";
		e2.comp_name="XYZ Pvt Ltd";
		System.out.println("====Employ1 details=======");
		System.out.println("Company Name is: "+e1.comp_name);
		System.out.println("Name is: "+e1.name);
		System.out.println("ID is: "+e1.id);
		e1.work();
		e1.giveBiometric();
		System.out.println("====Employ2 details=======");
		System.out.println("Company Name is: "+e2.comp_name);
		System.out.println("Name is: "+e2.name);
		System.out.println("ID is: "+e2.id);
		e2.work();
		e2.giveBiometric();
		System.out.println("====Employ3 details=======");
		System.out.println("Company Name is: "+e3.comp_name);
		System.out.println("Name is: "+e3.name);
		System.out.println("ID is: "+e3.id);
		e3.work();
		e3.giveBiometric();


	}
}







