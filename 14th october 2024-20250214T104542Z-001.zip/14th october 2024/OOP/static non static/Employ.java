class Employ
{
	static int x=40;
	int y=70;
	public static  void test(){
		System.out.println("static test method");
		System.out.println("x is: "+x);
		demo();
		Employ e1=new Employ();
		System.out.println("y is: "+e1.y);
		e1.run();
	}
	public static  void demo(){
		System.out.println("static demo method");
	}
	public  void start(){
		System.out.println("non-static start method");
		System.out.println("y is: "+this.y);
		this.run();
		System.out.println("x is: "+x);
		demo();
	}
	public void run(){
		System.out.println("non-static run method");
	}
	public static void main(String[] args){
		System.out.println("This is main method");
		test();
		System.out.println("==============");
		Employ e1=new Employ();
		System.out.println("y from main: "+e1.y);
		e1.start();
	}
}







