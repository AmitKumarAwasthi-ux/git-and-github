class Car
{
	String name;
	int price;
	String color;
	Car(){
	}
	Car(Car p){//copy constructor
		this.name=p.name;
		this.price=p.price;
		this.color=p.color;
	}
	Car(Car p, String color){//copy constructor
		this(p.name, p.price, color);
		//this.name=p.name;
		//this.price=p.price;
		//this.color=color;
	}
	Car(String name, int price, String color){
		this.name=name;
		this.price=price;
		this.color=color;
	}
	public void getDetails(){
		System.out.println("Name is: "+name);
		System.out.println("Price is: "+price);
		System.out.println("Color is: "+color);
		System.out.println("==================");
	}

}	







