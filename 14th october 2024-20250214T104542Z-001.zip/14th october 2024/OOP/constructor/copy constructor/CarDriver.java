class CarDriver
{
	public static void main(String[] args)
	{
		System.out.println("main STarts");
		Car c1=new Car("TATA", 2432523, "white");
		Car c2=new Car("Maruti", 4432523, "Black");
		Car c3=new Car("audi", 24832523, "white");
		Car c4=new Car("bmw", 44032523, "Black");
		Car c5=new Car();
		Car c6=new Car(c2);
		Car c7=new Car(c4);
		Car c8=new Car(c3);
		Car c9=new Car(c6);
		Car c10=new Car(c1,"Yellow");

		c1.getDetails();
		c2.getDetails();
		c3.getDetails();
		c4.getDetails();
		c5.getDetails();
		c6.getDetails();
		c7.getDetails();
		c8.getDetails();
		c9.getDetails();
		c10.getDetails();

		System.out.println("main Ends!");
	}
}







