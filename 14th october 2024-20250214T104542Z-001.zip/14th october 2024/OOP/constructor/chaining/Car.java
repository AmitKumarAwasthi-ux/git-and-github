class Car
{
	String name;
	int price;
	String color;
	String type;
	Car(){
		System.out.println("Car Object is created");
	}
	Car(String name){
		this();
		this.name=name;
	}
	Car(String name, int price){
		this(name);
		this.price=price;
	}
	Car(String name, int price, String color){
		this(name, price);
		this.color=color;
	}
	Car(String name, int price, String color, String type){
		this(name, price, color);
		this.type=type;
	}

	public void getDetails(){
		System.out.println("Name is: "+name);
		System.out.println("Price is: "+price);
		System.out.println("Color is: "+color);
		System.out.println("Type is: "+type);

		System.out.println("==================");
	}

}	







