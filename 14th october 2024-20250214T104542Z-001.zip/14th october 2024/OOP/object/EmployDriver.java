class EmployDriver
{
	public static void main(String[] args)
	{
		System.out.println("main STarts");
		Employ e1=new Employ();
		Employ e2=new Employ();
		System.out.println(e1);
		System.out.println(e2);
		e1.name="Mohan";//initialization
		e2.name="SOhan";
		System.out.println("====Employ1 details=======");
		System.out.println("Name is: "+e1.name);
		System.out.println("ID is: "+e1.id);
		System.out.println("Salary is: "+e1.salary);
		e1.work();
		System.out.println("====Employ2 details=======");
		System.out.println("Name is: "+e2.name);
		System.out.println("ID is: "+e2.id);
		System.out.println("Salary is: "+e2.salary);
		e2.work();
	}
}







