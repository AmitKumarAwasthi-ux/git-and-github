class Employ
{
	String name;
	int id;
	double salary;
	public void work(){
		System.out.println("Employ is working");
	}
}







