class EmployDriver
{
	public static void main(String[] args)
	{
		System.out.println("main STarts");
		Employ e1=new Employ();
		Employ e2=new Employ();
		Employ e3=new Employ();

		e1.setValue("Mohan", 356, 46547.56);
		e2.setValue("Sohan", 350, 40547.56);
		e3.setValue("Rohan", 306, 76547.56);

		e1.getDetails();
		e2.getDetails();
		e3.getDetails();
	}
}







