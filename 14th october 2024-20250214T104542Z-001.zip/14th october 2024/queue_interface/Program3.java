package queue_interface;
import java.util.*;
public class Program3 {
	public static void main(String[] args) {
		int[] a=new int[] {23, 34, 20, 12, 45, 33, 87, 28, 31};
		sortInAscending(a);
	}
	public static void sortInAscending(int[] a) {
		Queue<Integer> q1=new PriorityQueue<>();
		for(int x:a) {
			q1.offer(x);
		}
		while(!q1.isEmpty())
			System.out.print(q1.poll()+" ");
		
	}

}
