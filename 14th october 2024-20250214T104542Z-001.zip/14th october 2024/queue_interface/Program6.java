package queue_interface;
import java.util.*;
public class Program6 {
	
	public static void main(String[] args) {
		Collection<Integer> c1=new LinkedHashSet<>();
		c1.add(23);c1.add(45);c1.add(55);
		c1.add(40);c1.add(43);c1.add(25);
		
		Integer[] arr=c1.toArray(new Integer[0]);
		
		for(int i=0;i<arr.length;i++)
			System.out.println(arr[i]);
		
	}

}