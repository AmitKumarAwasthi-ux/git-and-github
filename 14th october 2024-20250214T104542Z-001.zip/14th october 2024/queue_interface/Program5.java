package queue_interface;

import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.*;
public class Program5 {
	public static void main(String[] args) {
		int[] a=new int[] {23, 34, 20, 12, 45, 33, 87, 28, 31};
		sortInDescending(a);
		System.out.println(Arrays.toString(a));
	}
	public static void sortInDescending(int[] a) {
		Queue<Integer> q1=new PriorityQueue<>(Comparator.reverseOrder());
		
		for(int x:a) {
			q1.offer(x);
		}
		for(int i=0;i<a.length;i++)
			a[i]=q1.poll();
	}
}
