package queue_interface;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
public class Program2 {
	public static void main(String[] args) {
		Queue<Integer> q1=new PriorityQueue<>(Comparator.reverseOrder());
		q1.add(34);q1.add(29);q1.add(33);
		q1.add(40);q1.add(34);q1.add(20);
		System.out.println(q1);
		while(!q1.isEmpty())
			System.out.print(q1.poll()+" ");
	}

}
