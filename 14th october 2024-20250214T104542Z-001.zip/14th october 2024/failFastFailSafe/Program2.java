package failFastFailSafe;
import java.util.concurrent.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Program2 {
	public static void main(String[] args) {
		Collection<Integer> c1=new CopyOnWriteArrayList<>();
		c1.add(28);c1.add(45);c1.add(56);
		c1.add(42);c1.add(33);c1.add(50);
		System.out.println("Original C1: "+c1);
		Iterator<Integer> itr=c1.iterator();
		while(itr.hasNext()) {
			int x=itr.next();
			if(x%2==1)
				c1.add(100);
			System.out.println(x);
		}
		System.out.println("Modified c1: "+c1);
	}

}
