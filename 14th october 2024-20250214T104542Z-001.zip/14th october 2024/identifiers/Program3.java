class Program3
{
	public static void main(String[] args)
	{
		int x;
		Program3 y;
		Laptop l;
		Car c; 
		System.out.println("====Program3 starts====");
		System.out.println(args.length);
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		System.out.println("========Program Ends=======");
	}
}
class Laptop{
}
interface Car{
}






