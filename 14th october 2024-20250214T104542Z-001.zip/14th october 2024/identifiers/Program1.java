class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is Program1");
		System.out.println(12+30*8);
	}

}






