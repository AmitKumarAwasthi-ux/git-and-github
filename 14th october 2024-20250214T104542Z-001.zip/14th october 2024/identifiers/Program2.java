class Program2
{
	public static void main(String[] args)
	{
		System.out.println("====Program2 starts====");
		int[] a={12, 15, 20, 30, 10, 43};
		System.out.println(a.length);
		System.out.println(a[0]);
		System.out.println(a[3]);
		System.out.println(a[6]);
		System.out.println("========Program Ends=======");
	}

}






