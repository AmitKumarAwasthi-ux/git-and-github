package collection_framework;

import java.util.ArrayList;
import java.util.Collection;

public class StringLength {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		c1.add("mohan is here");
		c1.add("john is here");
		c1.add("ram is coming");
		c1.add("shyam is going");
		c1.add("sfdsg ryr");
		c1.add("sdf ergr erh");
		System.out.println("c1 is: "+c1);
		getStringLength(c1);
		
	}
	public static void getStringLength(Collection c) {
		for(Object x:c) {
			System.out.println(x+" length is: "+((String)x).length());
		}
	}

}
