package collection_framework;
import java.util.ArrayList;
import java.util.List;
public class Program12 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);
		l1.add(40);
		l1.add(50);
		l1.add(55);
		System.out.println(l1);
		l1.remove((Object)55);
		System.out.println(l1);
		int sum=0;
		for(int x:l1) {
			sum=sum+x;
		}
		System.out.println(sum);
		
	}

}
