package collection_framework;

public class Test {
	
	public  Car   car() {
		System.out.println("this is car method");
	return new Car();
	}

}
