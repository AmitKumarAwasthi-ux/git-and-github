package collection_framework;

import java.util.ArrayList;
import java.util.Collection;

public class RemoveElements {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		c1.add(34);
		c1.add(55);
		c1.add("mohan");
		c1.add(33.56);
		c1.add('@');
		c1.add(55);
		System.out.println("c1 is: "+c1);
		removeElement(c1);
	}
	public static void removeElement(Collection c) {
		for(Object x:c) {
			if(!(x instanceof Integer))
				c.remove(x);	
		}
	System.out.println("Collection is Now: "+c);
	}
}
