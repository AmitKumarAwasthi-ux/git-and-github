package collection_framework;
import java.util.*;
public class Program3 {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		
		/**Cursor Object is created on c1
		 * and it is stored on itr refrence
		 */
		Iterator itr=c1.iterator();
	}

}
