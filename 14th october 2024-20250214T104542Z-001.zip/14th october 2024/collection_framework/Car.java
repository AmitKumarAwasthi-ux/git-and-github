package collection_framework;

public class Car {
	
	public void hasNext() {
		System.out.println("hasNext method");
	}
	public void next() {
		System.out.println("next method");
	}

}
