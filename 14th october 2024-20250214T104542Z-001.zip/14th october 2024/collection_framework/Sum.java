package collection_framework;

import java.util.ArrayList;
import java.util.Collection;

public class Sum {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		c1.add(34);
		c1.add(55);
		c1.add("mohan");
		c1.add(33.56);
		c1.add('@');
		c1.add(55);
		System.out.println("c1 is: "+c1);
		int sum=getIntegerSum(c1);
		System.out.println("Sum of all integers are: "+sum);
		
	}
	public static int getIntegerSum(Collection c) {
		int sum=0;
		for(Object x:c) {
			if(x instanceof Integer)
				sum=sum+(Integer)x;
		}
	return sum;
	}

}
