package collection_framework;

public class CarDriver {
	public static void main(String[] args) {
		Test t1=new Test();
		Car c1=t1.car();//Car c1=new Car();
		System.out.println(c1);
		c1.hasNext();
		c1.next();
	} 
}
