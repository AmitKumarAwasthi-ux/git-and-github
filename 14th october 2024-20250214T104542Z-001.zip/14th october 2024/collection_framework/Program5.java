package collection_framework;

import java.util.Collection;
import java.util.Set;

public class Program5 {
	public static void main(String[] args) {
		Collection c1=new HashSet();
		System.out.println("c1 is: "+c1);
		c1.add(23);
		c1.add(45);
		System.out.println("c1 is: "+c1);
		c1.add(30);
		System.out.println(c1.add(45));
		System.out.println("c1 is: "+c1);
	}

}
