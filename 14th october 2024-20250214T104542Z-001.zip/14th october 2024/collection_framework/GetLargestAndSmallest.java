package collection_framework;

import java.util.ArrayList;
import java.util.Collection;

public class GetLargestAndSmallest {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		c1.add(34);
		c1.add(55);
		c1.add(80);
		c1.add(33);
		c1.add(56);
		c1.add(55);
		System.out.println("c1 is: "+c1);
		getLargestAndSmallest(c1);
		
	}
	public static void getLargestAndSmallest(Collection c) {
		int big=Integer.MIN_VALUE; int small=Integer.MAX_VALUE;
		for(Object x:c) {
			int temp=(int)x;
			if(temp>big)
				big=temp;
			if(temp<small)
				small=temp;
		}
		System.out.println("Biggest is: "+big);
		System.out.println("Smallest is: "+small);
	}

}
