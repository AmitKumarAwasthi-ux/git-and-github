package collection_framework;
import java.util.*;
public class PrintAndCountInteger {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		c1.add(34);
		c1.add(55);
		c1.add("mohan");
		c1.add(33.56);
		c1.add('@');
		c1.add(55);
		System.out.println("c1 is: "+c1);
		System.out.println("All Integers are Below: ");
		countInteger(c1);
		
	}
	public static void countInteger(Collection c) {
		int count=0;
		for(Object x:c) {
			if(x instanceof Integer) {
				System.out.print(x+" ");
				count++;
			}
		}
		System.out.println("\nTotal Integers are: "+count);
	}

}
