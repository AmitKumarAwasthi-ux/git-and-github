package collection_framework;
import java.util.*;
public class Program1 {
	public static void main(String[] args) {
		int[] a=new int[10];
		Collection c1=new ArrayList();
		c1.add(45);
		c1.add(67);
		c1.add(23.56);
		c1.add("abc");
		System.out.println(c1);
	}

}
