package collection_framework;
import java.util.*;
public class Program4 {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		System.out.println("c1 is: "+c1);
		c1.add(23);
		c1.add(45.6);
		c1.add(45);
		System.out.println("c1 is: "+c1);
		c1.add(30);
		System.out.println(c1.add(45));
		System.out.println("c1 is: "+c1);
	}

}
