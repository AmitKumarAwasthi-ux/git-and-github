package collection_framework;

public class Program9 {

}
