package collection_framework;
import java.util.*;
public class Program11 {
	public static void main(String[] args) {
		List l1=new ArrayList();
		l1.add(34);
		l1.add(0,23);
		l1.add(55);
		l1.add(1, 50);
		l1.add(4, null);
		l1.add(5, 100);
		l1.remove(2);
		System.out.println(l1);
		
	}

}
  










