package collection_framework;

import java.util.ArrayList;
import java.util.Collection;
public class Program7 {
	public static void main(String[] args) {
		Collection c1=new ArrayList();
		c1.add(23);
		c1.add(45);
		c1.add(30);
		Collection c2=new ArrayList();
		c2.add(77);
		c2.add(45);
		c2.add(96);
		System.out.println("c1 is: "+c1);
		System.out.println("c2 is: "+c2);
		c1.addAll(c2);
		System.out.println("Now c1 is: "+c1);
	}

}
