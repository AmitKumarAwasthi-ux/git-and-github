package collection_framework;
import java.util.*;
public class RemoveDuplicates {
	public static void main(String[] args) {
		int[] a= {12, 18, 20, 12, 20, 18, 30, 12, 40, 12, 30};
		removeDuplicates(a);
	}
	public static void removeDuplicates(int[] a) {
		Collection c=new ArrayList();
		for(int x:a) {
			if(!c.contains(x))
				c.add(x);
		}
		System.out.println("All Unique Elements are: "+c);
		
	}

}
