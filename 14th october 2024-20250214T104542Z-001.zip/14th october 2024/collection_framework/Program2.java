package collection_framework;
import java.util.*;
public class Program2 {
	public static void main(String[] args) {
		Map m1=new LinkedHashMap();
		m1.put(12, "mohan");
		m1.put(10, "sohan");
		m1.put(8, "rohan");
		System.out.println(m1);
	}

}
