class Program3
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		getSum();
		System.out.println("Program Ends");
	}
	public static void getSum()
	{
		int n=100;
		int sum=0;
		int i=1;
		while(i<=n){
			if(i%8==0 && i%10==8)
				sum=sum+i;
		i++;
		}
	System.out.println("Sum is: "+sum);
	}
}