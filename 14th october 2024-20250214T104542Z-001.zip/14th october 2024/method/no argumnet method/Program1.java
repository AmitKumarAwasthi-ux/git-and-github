class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		int n=436547;
		getFactorial();
		getFactorial();
		getFactorial();
		System.out.println("Program Ends");
	}
	public static void getFactorial()
	{
		int n=6;
		int fact=1;
		int i=1;
		while(i<=n){
			fact=fact*i;
		i++;
		}
	System.out.println(n+"!= "+fact);
	}
}