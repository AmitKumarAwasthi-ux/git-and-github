class Factorial
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		getFactorial(6);
		getFactorial(4);
		getFactorial(7);
		System.out.println("Program Ends");
	}
	public static void getFactorial(int n)
	{
		int fact=1;
		int i=1;
		while(i<=n){
			fact=fact*i;
		i++;
		}
	System.out.println(n+"!= "+fact);
	}
}