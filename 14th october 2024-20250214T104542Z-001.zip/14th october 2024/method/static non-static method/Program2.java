class Program2
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method of Program2");
		Car.start();
		Car c1=new Car();
		c1.drive();
		String[] name={};
		Car.main(name);
		System.out.println("Program Ends");
	}
}