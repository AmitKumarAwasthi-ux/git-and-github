class Car
{
	public static void start()
	{
		System.out.println("Start Car");
	}
	public static void main(String[] args)
	{
		System.out.println("This is Main method of Car");
		Car.start();
		Car c1=new Car();
		c1.drive();
		System.out.println("Program Ends");
	}
	public void drive()
	{
		System.out.println("Drive Car");
	}
}