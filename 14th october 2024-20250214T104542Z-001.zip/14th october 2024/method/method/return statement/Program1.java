class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is main method");
		System.out.println(getSquare(12));
		System.out.println("Program Ends");
	}
	public static int getSquare(int n)
	{
		int sq=n*n;
		System.out.println("Square of "+n+" is: "+sq);
	return sq;
	}
	public static void test()
	{
		System.out.println("This is test method");
	}
}






