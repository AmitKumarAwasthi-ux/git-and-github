class Program2
{
	public static void main(String[] args)
	{
		System.out.println("This is main method");
		int x=-34;
		if(x>0)
		{
			System.out.println(x+" is a +ve Number");
		return ;
		}
		System.out.println(x+" is a -ve Number");
		System.out.println("Program Ends");
	}
}






