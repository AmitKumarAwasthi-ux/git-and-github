class Program5
{
	public static void main(String[] args)
	{
		System.out.println("This is main method");
		int x=12;
		int y=8;
		int z=10;
		int sum=getSquare(x)+getSquare(y)+getSquare(z);
		System.out.println("Sum is: "+sum);
		System.out.println("Program Ends");
	}
	public static int getSquare(int n)
	{
		int sq=n*n;
		System.out.println("Square of "+n+" is: "+sq);
	return sq;
	}
}






