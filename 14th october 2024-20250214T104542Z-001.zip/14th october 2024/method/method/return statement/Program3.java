class Program3
{
	public static void main(String[] args)
	{
		int x=12;
		int y=8;
		int z=10;
		System.out.println("This is main method");
		System.out.println("Sum is: "+(getSquare(x)+getSquare(y)+getSquare(z)));
		System.out.println("Program Ends");
	}
	public static int getSquare(int n)
	{
		int sq=n*n;
		System.out.println("Square of "+n+" is: "+sq);
	return sq;
	}
}






