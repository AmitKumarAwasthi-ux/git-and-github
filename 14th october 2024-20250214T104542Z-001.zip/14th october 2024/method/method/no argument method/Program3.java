class Program3
{

	public static void main(String[] args)
	{
		System.out.println("This is main method of Program3");
		System.out.println("================");
		Program2.test();
		System.out.println("================");
		Program1.test();
		System.out.println("================");
		System.out.println("Program Ends");
	}
}






