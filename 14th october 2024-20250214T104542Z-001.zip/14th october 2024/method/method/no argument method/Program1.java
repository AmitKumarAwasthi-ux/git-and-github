class Program1
{
	public static void test()
	{
		System.out.println("This is test method of Program1");
	}

	public static void main(String[] args)
	{
		System.out.println("This is main method");
		test();
		demo();
		demo();
		test();
		System.out.println("Program Ends");
	}
	public static void demo()
	{
		System.out.println("This is demo method");
	}

}






