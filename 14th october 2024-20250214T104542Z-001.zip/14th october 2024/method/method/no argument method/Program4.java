class Program4
{

	public static void main(String[] args)
	{
		System.out.println("This is main method of Program4");
		getLastDigit();
		System.out.println("Program Ends");
	}
	public static void getLastDigit()
	{
		int n=35477;
		int lastDigit=n%10;
		System.out.println(lastDigit);
	}
}






