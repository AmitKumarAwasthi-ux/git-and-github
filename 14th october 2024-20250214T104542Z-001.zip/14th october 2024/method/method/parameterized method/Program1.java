class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is main method");
		int x=12;
		getSquare(x);
		int y=43;
		getSquare(y);
		int z=38;
		getSquare(z);
		getSquare(21);
		System.out.println("Program Ends");
	}
	public static void getSquare(int n)
	{
		int sq=n*n;
		System.out.println("Square of "+n+" is: "+sq);
	}
}






