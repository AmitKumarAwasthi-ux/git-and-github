class Program2
{
	static int count=0;
	public static void main(String[] args){
		System.out.println("This is Main method");
		demo();
		System.out.println("Program Ends");
	}
	public static void demo(){
		count++;
		System.out.println("This is demo method call: "+count);
		demo();
	}
}