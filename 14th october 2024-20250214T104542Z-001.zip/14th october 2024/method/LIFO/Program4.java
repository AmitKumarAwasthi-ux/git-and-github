class Program4
{
	public static void main(String[] args){
		System.out.println("This is Main method");
		demo();
		System.out.println("Program Ends");
	}
	public static void test(){
		System.out.println("This is test method");
		System.out.println("Test Ends");
	}
	public static void demo(){
		System.out.println("This is demo method");
		test();
		start();
		System.out.println("Demo Ends");
	}
	public static void start(){
		System.out.println("This is start method");
		test();
		System.out.println("start Ends");
	}

}