class Program2
{
	public static void test()
	{
		System.out.println("This is Test method");
		System.out.println("Test ends");
	}
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		demo();
		System.out.println("Program Ends");
	}
	public static void demo()
	{
		System.out.println("This is demo method");
		test();
		System.out.println("demo ends");

	}
}