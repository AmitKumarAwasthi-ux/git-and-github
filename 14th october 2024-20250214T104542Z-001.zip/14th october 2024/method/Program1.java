class Program1
{
	public static void test()
	{
		System.out.println("This is Test method");
	}
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		demo();
		test();
		demo();
		System.out.println("Program Ends");
	}
	public static void demo()
	{
		System.out.println("This is demo method");
	}
}