import java.util.Scanner;
class FactorialUpto15Second
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the range: ");
		int range=sc.nextInt();
		System.out.println("Factorials of all numbers upto "+range+" are Below:");
		int i=1;
		while(i<=range){
			getFactorial(i);
		i++;
		}
	}
	public static void getFactorial(int n)
	{
		int fact=1;
		int i=1;
		while(i<=n){
			fact=fact*i;
		i++;
		}
	System.out.println(n+"!= "+fact);
	}
}