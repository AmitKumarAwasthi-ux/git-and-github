class FactorialUpto15
{
	public static void main(String[] args)
	{
		int i=1;
		while(i<=15){
			getFactorial(i);
		i++;
		}
	}
	public static void getFactorial(int n)
	{
		int fact=1;
		int i=1;
		while(i<=n){
			fact=fact*i;
		i++;
		}
	System.out.println(n+"!= "+fact);
	}
}