class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		System.out.println("Length is: "+args.length);
		System.out.println("1st Element is: "+args[0]);
		System.out.println("2nd Element is: "+args[1]);
		System.out.println("Program Ends");
	}
}