package interface_part;

public interface WebDriver1 extends SearchContext1{
	
	public void get();

}
