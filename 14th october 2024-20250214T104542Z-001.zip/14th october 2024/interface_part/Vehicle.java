package interface_part;

public interface Vehicle {
	int x=45;
	
	public void start();
	public void stop();
	
	

}
