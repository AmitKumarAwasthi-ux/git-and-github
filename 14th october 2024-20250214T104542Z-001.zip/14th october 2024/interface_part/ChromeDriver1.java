package interface_part;

public class ChromeDriver1 extends RemoteWebDriver1{

}
