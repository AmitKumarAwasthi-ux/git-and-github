package interface_part;

public interface SearchContext1 {
	
	public void findElement();
	
	private void start() {
		System.out.println("private method");
	}
	
	default void test() {
		System.out.println("default test method");
		start();
	}

}
