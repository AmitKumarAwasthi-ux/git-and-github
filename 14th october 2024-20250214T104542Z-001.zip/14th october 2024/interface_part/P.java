package interface_part;

public interface P {

}
