package interface_part;

public interface A {

}
