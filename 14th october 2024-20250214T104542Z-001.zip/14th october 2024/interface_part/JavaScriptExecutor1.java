package interface_part;

public interface JavaScriptExecutor1 {
	
	public void executeScript();

}
