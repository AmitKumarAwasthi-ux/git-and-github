package interface_part;

public interface TakeScreenshot1 {
	
	
	public void getScreenshot();

}
