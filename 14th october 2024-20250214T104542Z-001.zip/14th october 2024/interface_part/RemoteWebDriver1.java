package interface_part;

public class RemoteWebDriver1 implements WebDriver1, JavaScriptExecutor1, TakeScreenshot1{
	
	
	public void test() {
		System.out.println("test method is Overridden");
	}
	public void findElement() {
		System.out.println("FInd Elenent is implemented");
	}
	public void get() {
		System.out.println("Get is implemented");
	}
	public void executeScript() {
		System.out.println("Execute Script is implemented");
	}
	public void getScreenshot() {
		System.out.println("getScreenshot is implemented");
	}
}
