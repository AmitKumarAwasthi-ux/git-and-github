package interface_part;

public class ElectricCar implements Car{
	
	public void start() {
		System.out.println("STart the ElectricCar");
	}
	public void stop() {
		System.out.println("Stop the electric Car");
	}
	public void openGate() {
		System.out.println("Open gate in Electric Car");
	}
	
	

}
