package interface_part;

public interface Car extends Vehicle{
	
	public void openGate();

}
