package interface_part;

public class FirefoxDriver1 extends RemoteWebDriver1{

}
