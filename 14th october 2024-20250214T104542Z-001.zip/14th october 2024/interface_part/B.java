package interface_part;

public interface B {

}
