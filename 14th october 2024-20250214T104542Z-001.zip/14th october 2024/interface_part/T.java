package interface_part;

public class T {

}
