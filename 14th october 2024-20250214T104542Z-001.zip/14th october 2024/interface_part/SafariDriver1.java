package interface_part;

public class SafariDriver1 extends RemoteWebDriver1{

}
