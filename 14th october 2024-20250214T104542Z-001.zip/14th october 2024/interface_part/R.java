package interface_part;

public class R extends K implements P, Q{

}
