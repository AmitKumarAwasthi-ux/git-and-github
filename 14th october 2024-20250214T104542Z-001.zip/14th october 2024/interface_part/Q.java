package interface_part;

public interface Q {

}
