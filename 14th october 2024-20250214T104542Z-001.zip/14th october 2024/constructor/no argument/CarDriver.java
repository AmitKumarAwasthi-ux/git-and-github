class CarDriver
{
	public static void main(String[] args)
	{
		System.out.println("main STarts");
		Car c1=new Car();
		Car c2=new Car();
		Car c3=new Car();
		Car c4=new Car();
		Car c5=new Car();
		Car c6=new Car();
		Car c7=new Car();
		Car c8=new Car();
		Car c9=new Car();
		System.out.println("Total Object created is: "+Car.count);
		System.out.println("main Ends!");
	}
}







