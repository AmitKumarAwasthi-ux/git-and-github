class CarDriver
{
	public static void main(String[] args)
	{
		System.out.println("main STarts");
		Car c1=new Car("TATA", 2432523, "white");
		Car c2=new Car("Maruti", 4432523, "Black");
		Car c3=new Car();
		Car c4=new Car("TATA");
		Car c5=new Car("Audi", 4576588);
		Car c6=new Car("KIA");
		Car c7=new Car("bmw", "red");

		c1.getDetails();
		c2.getDetails();
		c3.getDetails();
		c4.getDetails();
		c5.getDetails();
		c6.getDetails();
		c7.getDetails();

		System.out.println("main Ends!");
	}
}







