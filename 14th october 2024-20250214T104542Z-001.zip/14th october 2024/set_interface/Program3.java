package set_interface;
import java.util.HashSet;
import java.util.*;
public class Program3 {
	public static void main(String[] args) {
		TreeSet<Integer> s1=new TreeSet<>();
		s1.add(34); s1.add(54); s1.add(70);
		s1.add(33); s1.add(53); s1.add(48);	
		System.out.println(s1);//[33, 34, 48, 53, 54, 70]
		System.out.println(s1.first());
		System.out.println(s1.last());
		System.out.println("=============");
		System.out.println(s1.lower(40));
		System.out.println(s1.higher(40));
		System.out.println("=============");
		System.out.println(s1.floor(40));
		System.out.println(s1.ceiling(40));
	}

}
