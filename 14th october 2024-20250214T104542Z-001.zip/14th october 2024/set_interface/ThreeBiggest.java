package set_interface;
import java.util.*;
public class ThreeBiggest {
	public static void main(String[] args) {
		int[] a=new int[] {45, 34, 12, 45, 56, 67, 62, 22, 33, 48};
		getThreeBiggest(a);
	}
	public static void getThreeBiggest(int[] a) {
		System.out.println("Three Biggest Elements are: ");
		TreeSet<Integer> t1=new TreeSet<>();
		for(int p:a)
			t1.add(p);
		Iterator<Integer> itr=t1.descendingIterator();
		int count=0;
		while(itr.hasNext()) {
			count++;
			System.out.print(itr.next()+" ");
			if(count==3)
				return;
		}
		
		
	}

}
