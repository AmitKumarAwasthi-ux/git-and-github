package set_interface;

import java.util.HashSet;
import java.util.Set;

public class Program2 {
	public static void main(String[] args) {
		Set s1=new HashSet<>();
		s1.add("mohan"); s1.add("sohan"); s1.add("rohan");
		s1.add("john"); s1.add("jack"); s1.add("mark");
		s1.add(null);s1.add(34);
		System.out.println(s1);
	}

}
