package set_interface;

import java.util.Iterator;
import java.util.TreeSet;

public class ThreeBiggest2 {
	public static void main(String[] args) {
		int[] a=new int[] {45, 45 , 40 , 32, 45};
		getThreeBiggest(a);
	}
	public static void getThreeBiggest(int[] a) {
		System.out.println("Three Biggest Elements are: ");
		TreeSet<Integer> t1=new TreeSet<>();
		for(int p:a)
			t1.add(p);
		if(t1.size()==1) {
			System.out.println(t1.last()+" "+t1.last()+" "+t1.last());
			return;
		}
		if(t1.size()==2) {
			System.out.print(t1.first()+" "+t1.last()+" "+t1.last());
			return;
		}
		Iterator<Integer> itr=t1.iterator();
		int count=0;
		while(itr.hasNext()) {
			count++;
				System.out.print(itr.next()+" ");
				if(count==3)
					return;
			}
		}

}
