package set_interface;
import java.util.*;
public class Program1 {
	public static void main(String[] args) {
		Set<Integer> s1=new HashSet<>();
		s1.add(40); s1.add(33); s1.add(50);
		s1.add(100); s1.add(37); s1.add(45);
		s1.add(34);
		System.out.println(s1);
	}

}
