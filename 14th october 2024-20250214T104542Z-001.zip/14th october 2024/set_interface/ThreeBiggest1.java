package set_interface;

import java.util.Arrays;
import java.util.Iterator;
import java.util.TreeSet;

public class ThreeBiggest1 {
	public static void main(String[] args) {
		int[] a=new int[] {45, 34, 12, 45, 56, 67, 62, 22, 33, 48};
		int[] big=getThreeBiggest(a);
		System.out.println("Three Biggest Elements are: ");
		System.out.println(Arrays.toString(big));
	}
	public static int[] getThreeBiggest(int[] a) {
		int[] big=new int[3];
		TreeSet<Integer> t1=new TreeSet<>();
		for(int p:a)
			t1.add(p);
		Iterator<Integer> itr=t1.descendingIterator();
		int count=0;
		while(itr.hasNext()) {
			big[count]=itr.next();
			count++;
			if(count==3)
				break;
		}
	return big;	
	}

}
