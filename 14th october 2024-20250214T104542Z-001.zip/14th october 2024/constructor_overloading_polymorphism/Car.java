package constructor_overloading_polymorphism;

public class Car {
	Car(){
		System.out.println("Car No-arg construcrtor");
	}
	Car(int x){
		System.out.println("Car int-arg construcrtor");
	}
	Car(boolean x){
		System.out.println("Car boolean-arg construcrtor");
	}
	Car(double x){
		System.out.println("Car double-arg construcrtor");
	}
	Car(String x){
		System.out.println("Car String-arg construcrtor");
	}

}
