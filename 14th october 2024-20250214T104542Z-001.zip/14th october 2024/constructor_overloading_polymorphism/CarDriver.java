package constructor_overloading_polymorphism;

public class CarDriver {
	public static void main(String[] args) {
		Car c1=new Car(23);
		System.out.println("==============");
		Car c2=new Car("abc");
		System.out.println("================");
		Car c3=new Car();
		System.out.println("================");
		Car c4=new Car(true);
	}

}
