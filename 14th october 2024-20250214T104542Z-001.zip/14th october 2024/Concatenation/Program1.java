class Program1
{
	public static void main(String[] args)
	{
		int a=18;
		int b=4;
		System.out.println(a+10+'d'+"abc"+a+b*2);
		
	}
}