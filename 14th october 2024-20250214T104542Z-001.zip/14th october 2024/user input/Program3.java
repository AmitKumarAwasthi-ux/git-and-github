import java.util.Scanner;
class Program3
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the String: ");
		String x=sc.next();

		System.out.println("String is: "+x);
	}
}