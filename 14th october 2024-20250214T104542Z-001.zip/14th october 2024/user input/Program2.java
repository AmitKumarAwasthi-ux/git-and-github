import java.util.Scanner;
class Program2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the 1st Number: ");
		int a=sc.nextInt();
		System.out.println("ENter the 2nd Number: ");
		int b=sc.nextInt();
		int sum=a+b;
		int diff=a-b;
		int mul=a*b;
		System.out.println("Sum of "+a+" and "+b+" is: "+sum);
		System.out.println("Difference of "+a+" and "+b+" is: "+diff);
		System.out.println("Product of "+a+" and "+b+" is: "+mul);
	}
}