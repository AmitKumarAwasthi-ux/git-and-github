import java.util.Scanner;
class Program6
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the String: ");
		char x=sc.nextLine().charAt(3);

		System.out.println("Character is: "+x);
	}
}