import java.util.Scanner;
class Case2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Age: ");
		int age=sc.nextInt();
		System.out.println("ENter the Name: ");
		sc.nextLine();
		String name=sc.nextLine();
		System.out.println("ENter the Weight: ");
		double weight=sc.nextDouble();
		System.out.println("ENter the City: ");
		sc.nextLine();
		String city=sc.nextLine();
		System.out.println("ENter the PIN: ");
		int pin=sc.nextInt();
		System.out.println("ENter the COuntry: ");
		sc.nextLine();
		String country=sc.nextLine();
		System.out.println("ENter the Email ID: ");
		String emailid=sc.nextLine();
		System.out.println("ENter the State: ");
		String state=sc.nextLine();
		System.out.println("=====Entered details are Below=====");
		System.out.println("Name is: "+name);
		System.out.println("Age is: "+age+" Years");
		System.out.println("Weight is: "+weight+" KG");
		System.out.println("CIty is: "+city);
		System.out.println("PIN is: "+pin);
		System.out.println("Country is: "+country);
		System.out.println("EMail ID is: "+emailid);
		System.out.println("State is: "+state);
	}
}