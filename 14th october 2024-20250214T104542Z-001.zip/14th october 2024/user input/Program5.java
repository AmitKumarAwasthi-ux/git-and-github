import java.util.Scanner;
class Program5
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the String: ");
		char x=sc.next().charAt(0);

		System.out.println("Character is: "+x);
	}
}