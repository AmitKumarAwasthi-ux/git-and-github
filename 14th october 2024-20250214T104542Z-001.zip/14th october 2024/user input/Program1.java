import java.util.Scanner;
class Program1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the value of a: ");
		int a=sc.nextInt();
		System.out.println("ENter the value of b: ");
		int b=sc.nextInt();
		int sum=a+b;
		int diff=a-b;
		System.out.println(a+"+"+b+"= "+sum);
		System.out.println(a+"-"+b+"= "+diff);
	}
}