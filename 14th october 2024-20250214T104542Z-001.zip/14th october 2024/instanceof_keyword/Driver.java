package instanceof_keyword;

public class Driver {
	public static void main(String[] args) {
		CheckData.test(23);
		System.out.println("==============");
		CheckData.test("abcde");
		System.out.println("==============");
		CheckData.test(23.7);
		System.out.println("==============");
		CheckData.test('@');
		System.out.println("==============");
		CheckData.test(true);
		System.out.println("==============");
		CheckData.test(new Car());
	}

}
