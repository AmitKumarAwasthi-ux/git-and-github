package instanceof_keyword;

public class Car {
	int x=34;

}
