package instanceof_keyword;

public class CheckData {
	
	public static void test(Object o) {
		if(o instanceof Integer) {
			System.out.println("o is: "+o);
			System.out.println("It is Integer");
			System.out.println((Integer)o+100);
		}else if(o instanceof String) {
			System.out.println("o is: "+o);
			System.out.println("It is String");
			String s=(String)o;
			System.out.println("Lengrh is: "+s.length());
		} else if(o instanceof Double) {
			System.out.println("o is: "+o);
			System.out.println("It is Double");
		} else if(o instanceof Character) {
			System.out.println("o is: "+o);
			System.out.println("It is Character");
		} else if(o instanceof Boolean) {
			System.out.println("o is: "+o);
			System.out.println("It is Boolean");
		} else if(o instanceof Car) {
			System.out.println("o is: "+o);
			System.out.println("It is Car Object");
			//Car c=(Car)o;
			System.out.println(((Car)o).x);
		} 
		else {
			System.out.println("o is "+o);
			System.out.println("It is Other type");
		}
	}

}
