class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		System.out.println(Math.E);
		System.out.println(Math.PI);
		double res=Math.pow(12, 3);
		System.out.println(res);
		System.out.println(Math.pow(6,4));
		System.out.println(Math.sqrt(145));
		System.out.println(Math.min(6,4));
		System.out.println(Math.max(6,4));
		System.out.println(Math.ceil(6.4));
		System.out.println(Math.floor(6.4));
		System.out.println(Math.abs(2-6));
		System.out.println("Program Ends");
	}
}