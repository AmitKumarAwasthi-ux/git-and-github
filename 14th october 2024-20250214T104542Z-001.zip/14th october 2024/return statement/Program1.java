import java.util.Scanner;
class Program1
{
	public static void main(String[] args)
	{
		System.out.println(demo());
	}
	public static void test()
	{
		System.out.println("Test method");
	}
	public static int demo()
	{
		System.out.println("demo method");
	return 12;
	}

}