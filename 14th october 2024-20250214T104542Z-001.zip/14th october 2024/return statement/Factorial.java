import java.uti.Scanner;
class Factorial
{
	public static void main(String[] args)
	{
		System.out.println("This is Main method");
		int x=4;
		int fact=getFactorial(x);
		System.out.println(x+"!= "+fact);
		System.out.println("Program Ends");
	}
	public static int getFactorial(int n)
	{
		int fact=1;
		int i=1;
		while(i<=n){
			fact=fact*i;
		i++;
		}
	return fact;
	}
}