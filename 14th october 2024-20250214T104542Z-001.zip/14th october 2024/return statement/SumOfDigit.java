import java.util.Scanner;
class SumOfDigit
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number: ");
		int n=sc.nextInt();
		int sum=getDigitSum(n);
		System.out.println("Digit sum is: "+sum);
		System.out.println("Program Ends");
	}
	public static int getDigitSum(int n)
	{
		int sum=0;
		while(n>0){
			int rem=n%10;
			sum=sum+rem;
		n=n/10;
		}
	return sum;
	}
}




