import java.util.Scanner;
class Factorial1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Number: ");
		int x=sc.nextInt();
		System.out.println(x+"!= "+getFactorial(x));
		System.out.println("Program Ends");
	}
	public static int getFactorial(int n)
	{
		int fact=1;
		int i=1;
		while(i<=n){
			fact=fact*i;
		i++;
		}
	return fact;
	}
}