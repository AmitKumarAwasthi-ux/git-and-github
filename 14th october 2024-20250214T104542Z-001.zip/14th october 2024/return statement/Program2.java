import java.util.Scanner;
class Program2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		if(n>0){
			System.out.println(n+" is Greter than Zero");
		return;
		}
		System.out.println(n+" is Smaller than Zero");
		System.out.println("This Line is Outside if block");
	}

}