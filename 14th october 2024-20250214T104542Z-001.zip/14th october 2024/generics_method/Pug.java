package generics_method;

public class Pug extends Dog{

}
