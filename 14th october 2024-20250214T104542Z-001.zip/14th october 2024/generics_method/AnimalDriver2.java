package generics_method;

import java.util.ArrayList;
import java.util.List;

public class AnimalDriver2 {
	public static void main(String[] args) {
			List<Animal> l1=new ArrayList<>();
			List<Dog> l2=new ArrayList<>();
			List<Pug> l3=new ArrayList<>();
			List<LivingThings> l4=new ArrayList<>();
			eat(l1);
			eat(l2);
			eat(l3);
			eat(l4);
		}
		public static void eat(List<? extends Animal> t1) {
			System.out.println("eat method");
		}
}
