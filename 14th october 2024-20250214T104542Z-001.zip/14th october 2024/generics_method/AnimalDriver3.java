package generics_method;

import java.util.ArrayList;
import java.util.List;

public class AnimalDriver3 {
	public static void main(String[] args) {
		List<LivingThings> l1=new ArrayList<>();
		List<Animal> l2=new ArrayList<>();
		List<Dog> l3=new ArrayList<>();
		List<Pug> l4=new ArrayList<>();
		eat(l1);
		eat(l2);
		eat(l3);
		eat(l4);
	}
	public static  void eat(List<? super Animal> l) {
		System.out.println("eat method");
	}

}
