package generics_method;
import java.util.*;
public class AnimalDriver {
	public static void main(String[] args) {
		List<Animal> l1=new ArrayList<>();
		l1.add(new Animal());
		l1.add(new Dog());
		l1.add(new Pug());
		eat(l1);
		List<Dog> l2=new ArrayList<>();
		List<Pug> l3=new ArrayList<>();
		List<LivingThings> l4=new ArrayList<>();
		eat(l2);
		eat(l3);
		eat(l4);
	}
	public static <T extends Animal> void eat(List<T> t1) {
		System.out.println("eat method");
	}

}
