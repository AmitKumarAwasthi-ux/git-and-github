package generics_method;

public class LivingThings {

}
