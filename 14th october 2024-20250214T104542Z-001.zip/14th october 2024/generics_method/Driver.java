package generics_method;

public class Driver {
	public static void main(String[] args) {
		test(23);
		test("abc");
		test(34.6);
		
	}
	public static <T> void test(T t) {
		System.out.println("Test method: "+t);
	}

}
