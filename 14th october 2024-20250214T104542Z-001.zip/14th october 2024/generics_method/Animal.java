package generics_method;

public class Animal extends LivingThings{

}
