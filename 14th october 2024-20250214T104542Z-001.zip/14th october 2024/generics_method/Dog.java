package generics_method;

public class Dog extends Animal{

}
