class Program1
{
	public static void main(String[] args)
	{
		System.out.println('\u0001');
		System.out.println('\u0002');
		System.out.println('\u0003');
		System.out.println('\u0004');
		System.out.println('\u0041');
		System.out.println('\u0042');
		System.out.println('\u0046');
		System.out.println('\u007e');
		System.out.println('\u221e');
		System.out.println('\u00b1');
		System.out.println('\u2265');
		System.out.println('\u00d7');





	}

}






