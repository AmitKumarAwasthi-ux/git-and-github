package wrapper_class;

public class Program5 {
	public static void main(String[] args) {
		String s1="2a38";
		System.out.println(s1+100);
		int p=Integer.parseInt(s1);
		System.out.println(p+100);
		System.out.println(p-100);
		System.out.println(p*2);
	}


}
