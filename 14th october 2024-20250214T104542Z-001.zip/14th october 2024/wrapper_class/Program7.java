package wrapper_class;

public class Program7 {
	public static void main(String[] args) {
		Object o2=58;
		System.out.println((Integer)o2+100);
		System.out.println("=============");
		int x=(Integer)o2;
		System.out.println(x+100);
	}

}
