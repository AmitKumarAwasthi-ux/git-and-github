package wrapper_class;

public class Program8 {
	public static void main(String[] args) {
		Object o=234;
		
		System.out.println(o);
		System.out.println((Double)o+100);//ClassCastException
		//Integer and Double is not related with inheritance
		
	}

}
