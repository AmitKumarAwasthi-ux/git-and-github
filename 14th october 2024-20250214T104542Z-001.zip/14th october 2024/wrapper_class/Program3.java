package wrapper_class;

public class Program3 {
	public static void main(String[] args) {
		double a=102.3455;
		String s1=Double.toString(a);
		System.out.println("Total Numeric Digits are: "+(s1.length()-1));
	}

}
