package wrapper_class;

public class Program1 {
	public static void main(String[] args) {
		int x=23;
	
		Integer y=4366;
		Integer z=new Integer(45);
		System.out.println(Integer.toHexString(4366));
		System.out.println(x+100);
		System.out.println(y+100);
		System.out.println(z+100);
	}

}
