package wrapper_class;

public class Program6 {
	public static void main(String[] args) {
		Object o="Mohan";
		String s=(String)o;
		System.out.println("Size of: "+s+" is: "+s.length());
		System.out.println("==================");
		System.out.println(((String)o).charAt(3));
		
		
	}

}
