package inheritance;

public class A {

}
