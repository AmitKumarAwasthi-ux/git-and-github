package inheritance;

public class B {

}
