package inheritance;
public class Vehicle {
	int p=30;
	
	Vehicle(){
		super();
		System.out.println("Vehicle No-arg constructor");
	}
	Vehicle(int x){
		super();
		System.out.println("Vehicle int-arg constructor");
	}
	
	

}





