package inheritance;

public class Driver {
	public static void main(String[] args) {
		Object o;
		Car c1=new Car();
		System.out.println("==============");
		Car c2=new Car(34);
	}

}
