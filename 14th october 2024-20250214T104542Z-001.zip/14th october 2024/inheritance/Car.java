package inheritance;

public class Car extends Vehicle{
	int q=90;
	
	Car(){
		super();
		System.out.println("Car No-arg Constructor");
	}
	Car(int y){
		super(20);
		System.out.println("Car int-arg Constructor");
	}

}
