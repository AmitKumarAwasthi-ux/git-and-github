package map_interface;
import java.util.*;
public class Program3 {
	public static void main(String[] args) {
		Map<String, Integer> m1=new HashMap<>();
		m1.put("abc", 45);
		m1.put("pqr", 36);
		m1.put(new String("abc"), 60);
		m1.put("p", 36);
		m1.put(null, 36);
		System.out.println(m1);
	}

}
