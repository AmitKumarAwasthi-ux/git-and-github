package map_interface;

public class Program2 {
	public static void main(String[] args) {
		String s1="mohan";
		String s2=new String("john");
		String s3=new String("mohan");
		String s4=new String("mohan");
		String s5="mohan";
		System.out.println(s1==s5);
		System.out.println(s1==s4);
		System.out.println(s4==s3);
		System.out.println("=================");
		System.out.println(s1.equals(s5));
		System.out.println(s1.equals(s4));
		System.out.println(s4.equals(s3));
	}

}



