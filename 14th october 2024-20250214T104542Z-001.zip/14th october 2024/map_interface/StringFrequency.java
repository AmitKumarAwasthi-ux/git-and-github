package map_interface;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class StringFrequency {
	public static void main(String[] args) {
		String s="abcaabcaadabc";
		getFrequency(s);
	}
	public static void getFrequency(String s) {
		s=s.toLowerCase();
		Map<Character, Integer> m1=new LinkedHashMap<>();
		char[] a=s.toCharArray();
		for(char x:a) {
			if(!m1.containsKey(x))
				m1.put(x, 1);
			else
				m1.put(x, m1.get(x)+1);
		}
		Set<Map.Entry<Character, Integer>>  ent=m1.entrySet();
		System.out.println(ent);
		
		for(Map.Entry<Character, Integer>  e:ent)
			System.out.println(e.getKey()+" is: "+e.getValue()+" times");
		}


}
