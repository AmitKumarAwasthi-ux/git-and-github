package map_interface;

import java.util.HashMap;
import java.util.*;

public class Program6 {
	public static void main(String[] args) {
		String s1="abc";
		String s2=new String("abc");
		String s3="abc";
		Map<String, Integer> m1=new IdentityHashMap<>();
		System.out.println(m1.put(s1, 10));//null
		System.out.println(m1.put("xyz", 30));//null
		System.out.println(m1.put(s1, 45));//10 or 45 or null
		m1.put(s2, 20);
		m1.put(s3, 30);
		System.out.println(m1);
	}

}
