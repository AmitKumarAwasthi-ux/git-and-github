package map_interface;

import java.util.HashMap;
import java.util.*;

public class SumOfAllElementsExactlyOnce {
	public static void main(String[] args) {
		int[] a=new int[] {10, 12, 18, 12, 10, 15, 12, 17, 12, 10};
		getFrequency(a);
	}
	public static void getFrequency(int[] a) {
		Map<Integer, Integer> m1=new HashMap<>();
		for(int x:a) {
			if(!m1.containsKey(x))
				m1.put(x, 1);
			else
				m1.put(x, m1.get(x)+1);
		}
		Set<Integer> key=m1.keySet();
		int sum=0;
		Iterator<Integer> itr=key.iterator();
		while(itr.hasNext())
			sum=sum+itr.next();
		System.out.println("Sum is: "+sum);
			
		
	}

}
