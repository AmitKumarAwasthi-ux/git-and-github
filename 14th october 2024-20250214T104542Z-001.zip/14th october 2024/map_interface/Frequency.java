package map_interface;
import java.util.*;
public class Frequency {
	public static void main(String[] args) {
		int[] a=new int[] {12, 23, 12, 34, 12, 20, 34, 18, 12, 23};
		getFrequency(a);
	}
	public static void getFrequency(int[] a) {
		Map<Integer, Integer> m1=new HashMap<>();
		for(int x:a) {
			if(!m1.containsKey(x))
				m1.put(x, 1);
			else
				m1.put(x, m1.get(x)+1);
		}
		System.out.println(m1);
	}

}
