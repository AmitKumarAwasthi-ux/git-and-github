package map_interface;
import java.util.Map;
public class Program1 {
	Map m1;

}
