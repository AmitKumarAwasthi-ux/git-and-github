package map_interface;
import java.util.*;
public class Program5 {
	public static void main(String[] args) {
		String s1="abc";
		String s2=new String("abc");
		String s3="abc";
		Map<String, Integer> m1=new HashMap<>();
		m1.put(s1, 10);
		m1.put(s2, 20);
		m1.put(s3, 30);
		System.out.println(m1);
	}

}
