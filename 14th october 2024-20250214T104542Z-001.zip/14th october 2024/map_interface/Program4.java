package map_interface;

import java.util.*;
import java.util.Map;

public class Program4 {
	public static void main(String[] args) {
		Map<String, Integer> m1=new IdentityHashMap<>();
		m1.put("abc", 45);
		m1.put("pqr", 36);
		m1.put(new String("abc"), 100000000);
		System.out.println(m1);
	}

}
