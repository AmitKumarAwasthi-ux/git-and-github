package map_interface;

import java.util.HashMap;
import java.util.*;

public class PrintAllElementsOnce {
	public static void main(String[] args) {
		int[] a=new int[] {10, 12, 18, 12, 10, 15, 12, 17, 12, 10};
		getFrequency(a);
	}
	public static void getFrequency(int[] a) {
		Map<Integer, Integer> m1=new LinkedHashMap<>();
		for(int x:a) {
			if(!m1.containsKey(x))
				m1.put(x, 1);
			else
				m1.put(x, m1.get(x)+1);
		}
		Set<Integer> key=m1.keySet();
		System.out.println(key);
		System.out.println("=============");
		Collection<Integer> val=m1.values();
		System.out.println(val);
	}

}
