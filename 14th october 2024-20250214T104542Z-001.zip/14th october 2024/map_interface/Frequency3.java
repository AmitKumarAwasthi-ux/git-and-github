package map_interface;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class Frequency3 {
	public static void main(String[] args) {
		int[] a=new int[] {10, 12, 18, 12, 10, 15, 12, 17, 12, 10};
		getFrequency(a);
	}
	public static void getFrequency(int[] a) {
		Map<Integer, Integer> m1=new LinkedHashMap<>();
		for(int x:a) {
			if(!m1.containsKey(x))
				m1.put(x, 1);
			else
				m1.put(x, m1.get(x)+1);
		}
		Set<Integer> key=m1.keySet();
		System.out.println(key);
		for(int k:key)
			System.out.println(k);
		System.out.println("=================");
		
		Set<Map.Entry<Integer, Integer>>  ent=m1.entrySet();
		System.out.println(ent);
		
		for(Map.Entry<Integer, Integer>  e:ent)
			System.out.println(e.getKey()+" is: "+e.getValue()+" times");
		}
}
