package comparator_sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class EmployDriver {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Service service=new Service();
		Employ e1=new Employ("mohan",123, 34643.56);
		service.addEmploy(e1);
		service.addEmploy(new Employ("john", 122, 46547.45));
		service.addEmploy(new Employ("sohan", 132, 46547.45));
		service.addEmploy(new Employ("jack", 102, 46547.45));
		service.addEmploy(new Employ("john2", 312, 32547.45));
		System.out.println("=====All Employ==========");
		service.getgAllEmploy();
		System.out.println("=====Search On Name===============");
		System.out.println("Enter the Name: ");
		String s=sc.nextLine();
		service.getEmployWithNameStartsWith(s);
		
		/*Collections.sort(l1, new NameComparatrorAscendingOrder());
		for(Employ x:l1)
			System.out.println(x);
		System.out.println("=====Sort on Name in Descending Order===============");
		Collections.sort(l1, new NameComparatorDescendingOrder());
		for(Employ x:l1)
			System.out.println(x);
		System.out.println("=====Sort on ID in Descending Order===============");
		Collections.sort(l1, new IDDescendingComparator());
		for(Employ x:l1)
			System.out.println(x);
		System.out.println("=====Sort on ID in Ascending Order===============");
		Collections.sort(l1, new IDAscendingComparator());
		for(Employ x:l1)
			System.out.println(x);*/
		
	}

}
