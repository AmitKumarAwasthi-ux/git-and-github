package comparator_sorting;

public class Employ {
	String name;
	int id;
	double salary;
	Employ(){}
	Employ(String name, int id, double salary){
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	public String toString() {
	return "Name: "+name+"\tID: "+id+"\tSalary: "+salary;
	}
	/*public int compareTo(Employ e) {
	return this.id-e.id;
	}
	public int compareTo(Employ e) {
		if(this.salary==e.salary)
			return this.id-e.id;
		return (int)(this.salary-e.salary);
	}*/
	public int compareTo(Employ e) {
		return this.name.compareToIgnoreCase(e.name);
	}

}
