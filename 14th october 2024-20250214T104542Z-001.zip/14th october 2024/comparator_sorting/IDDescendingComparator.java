package comparator_sorting;

import java.util.Comparator;

public class IDDescendingComparator implements Comparator<Employ>{

	public int compare(Employ e1, Employ e2) {
	return e2.id-e1.id;
	}

}
