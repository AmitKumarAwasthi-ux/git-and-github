package comparator_sorting;

import java.util.ArrayList;
import java.util.List;

public class Service {
	private List<Employ> l1=new ArrayList<>();
	
	public void addEmploy(Employ e) {
		l1.add(e);
	}
	public void getgAllEmploy() {
		for(Employ x:l1)
			System.out.println(x);
	}
	public void getEmployWithNameStartsWith(String s) {
		int count=0;
		for(Employ x:l1) {
			if(x.name.startsWith(s)) {
				System.out.println(x); count++;
			}
		}
		System.out.println("Total Such Employees are: "+count);
	}

}
