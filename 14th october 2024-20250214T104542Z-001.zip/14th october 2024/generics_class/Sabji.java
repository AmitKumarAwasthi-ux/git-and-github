package generics_class;

public class Sabji {
	
	
	public String toString() {
		return "This is Sabji";
	}

}
