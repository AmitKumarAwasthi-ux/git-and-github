package generics_class;

public class Roti {
	
	
	public String toString() {
		return "This is Roti";
	}
	
	
	

}
