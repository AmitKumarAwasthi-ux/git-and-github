package generics_class;

public class PairDriver {
	public static void main(String[] args) {
		Pair<Integer, String> p1=new Pair<>(12, "Mohan");
		Pair<Integer, String> p2=new Pair<>(13, "Sohan");
		Pair<Integer, String> p3=new Pair<>(14, "Rohan");
		Pair<Roti, Sabji> p4=new Pair<>(new Roti(), new Sabji());
		
		p1.getPairDetails();
		p2.getPairDetails();
		p3.getPairDetails();
		p4.getPairDetails();
	}

}
