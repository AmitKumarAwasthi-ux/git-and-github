package generics_class;

public class Driver {
	public static void main(String[] args) {
		Box<Roti> b1=new Box<>(new Roti());
		b1.displayDetails();
		
		Box<Rice> b2=new Box<>(new Rice());
		b2.displayDetails();
		Box<Sabji> b3=new Box<>(new Sabji());
		b3.displayDetails();
	}

}
