package generics_class;


public class Box<T> {
	T t;
	
	Box(T t){
		this.t=t;
	}
	public void displayDetails() {
		System.out.println(t);
	}

}
