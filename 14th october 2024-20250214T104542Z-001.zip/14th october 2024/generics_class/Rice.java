package generics_class;

public class Rice {
	
	
	public String toString() {
		return "This is Rice";
	}

}
