package generics_class;

public class GulabJamun {

}
