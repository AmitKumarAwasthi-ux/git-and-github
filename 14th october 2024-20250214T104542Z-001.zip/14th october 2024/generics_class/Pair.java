package generics_class;

public class Pair<T1, T2> {
	T1 t1;
	T2 t2;
	Pair(){
		
	}
	Pair(T1 t1, T2 t2){
		this.t1=t1;
		this.t2=t2;
	}
	public void getPairDetails() {
		System.out.println("Pair1 is: "+t1);
		System.out.println("Pair2 is: "+t2);
		System.out.println("================");
	}
}
