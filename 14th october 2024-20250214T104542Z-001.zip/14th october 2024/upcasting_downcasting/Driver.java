package upcasting_downcasting;

public class Driver {
	public static void main(String[] args) {
		System.out.println(new Car().x);
		System.out.println(new Car().a);
		System.out.println("==============");
		Vehicle v1=new Car();
		System.out.println(v1.x);
		System.out.println("==============");
		
		
	}

}
