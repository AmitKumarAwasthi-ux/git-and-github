package upcasting_downcasting;

public class Car extends Vehicle{
	int a=30;

}
