package upcasting_downcasting;

public class Bike extends Vehicle{
	int c=50;


}
