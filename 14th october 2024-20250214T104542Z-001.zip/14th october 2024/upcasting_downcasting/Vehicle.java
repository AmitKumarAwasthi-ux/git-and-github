package upcasting_downcasting;

public class Vehicle {
	int x=10;

}
