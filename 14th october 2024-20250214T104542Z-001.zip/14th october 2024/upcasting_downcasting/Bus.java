package upcasting_downcasting;

public class Bus extends Vehicle{
	int b=40;


}
