package upcasting_downcasting;

public class Driver1 {
	public static void main(String[] args) {
		Vehicle v1=new Car();
		Car c1=(Car)v1;
		System.out.println(c1.x);
		System.out.println(c1.a);
		System.out.println("=============");
		Vehicle v2=new Bus();
		Bus b1=(Bus)v2;
		System.out.println(b1.b);
		System.out.println(b1.x);
	}

}
