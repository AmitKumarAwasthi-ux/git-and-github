package collections_class;

public class Program14 {
	public static void main(String[] args) {
		String s1="def";
		String s2="abc";
		System.out.println(s1.compareToIgnoreCase(s2));
	}

}
