package collections_class;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Program10 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(34);l1.add(44);
		l1.add(33);l1.add(28);l1.add(34);
		System.out.println("Before Sorting: "+l1);
		int ind=Collections.binarySearch(l1, 34);
		System.out.println(ind);
	}

}
