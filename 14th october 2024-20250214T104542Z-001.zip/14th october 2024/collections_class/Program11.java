package collections_class;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Program11 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(34);l1.add(44);
		l1.add(33);l1.add(28);l1.add(34);
		List<Integer> l2=new ArrayList<>();
		l2.add(203);l2.add(24);l2.add(404);
		l2.add(303);l2.add(208);l2.add(304);
		
		System.out.println("Before Sorting: "+l1);
		Boolean result=Collections.disjoint(l1, l2);
		System.out.println(result);
	}

}
