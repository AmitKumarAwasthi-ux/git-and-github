package collections_class;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Program12 {
	public static void main(String[] args) {
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(34);l1.add(23);
		l1.add(23);l1.add(28);l1.add(25);
		System.out.println("Before Replacing: "+l1);
		Collections.replaceAll(l1, 23, 100);
		System.out.println("After Replacing: "+l1);
	}

}
