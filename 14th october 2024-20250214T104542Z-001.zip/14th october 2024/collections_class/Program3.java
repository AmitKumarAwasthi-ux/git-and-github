package collections_class;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Program3 {
	public static void main(String[] args) {
		String s1;
		Integer i1;
		Comparable c;
		Comparator c1;
		List<Integer> l1=new ArrayList<>();
		l1.add(23);l1.add(34);l1.add(44);
		l1.add(33);l1.add(28);l1.add(25);
		System.out.println("Before Sorting: "+l1);
		Collections.sort(l1);
		System.out.println("After Sorting: "+l1);
	}

}
