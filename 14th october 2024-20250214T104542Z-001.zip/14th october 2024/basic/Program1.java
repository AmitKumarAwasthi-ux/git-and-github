class Program1
{
	public static void main(String[] args)
	{
		System.out.println("This is Program1");
		System.out.println(12+30*8);
	}

}

class Program2
{
	public static void main(String[] args)
	{
		System.out.println("This is Program2");
		System.out.println(12+30+8/2);
	}

}
class Program3
{
	public static void main(String[] args)
	{
		System.out.println("This is Program3");
		System.out.println(12+30+8*2);
	}

}
class Program4
{
	public static void main(String[] args)
	{
		System.out.println("This is Program4");
		System.out.println(12+300+400);
	}

}







