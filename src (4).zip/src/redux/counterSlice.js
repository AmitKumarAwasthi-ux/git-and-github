import { createSlice } from "@reduxjs/toolkit";

// STEP 2 --> CREATE A SLICE/FEATURE
export let counterSlice = createSlice({
  name: "counter",
  initialState: 0,
  reducers: {
    increment: (state, action) => {
      console.log(action);
      return state + 1;
    },
    decrement: (state, action) => {
      console.log(action);
      return state - 1;
    },
    reset: (state, action) => {
      console.log(action);
      return 0;
    },
  },
});
export let { increment, decrement, reset } = counterSlice.actions;
