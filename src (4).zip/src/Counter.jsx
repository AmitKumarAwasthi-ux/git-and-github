import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { increment, decrement, reset } from "./redux/counterSlice";
const Counter = () => {
  let state = useSelector((state) => state);

  let dispatch = useDispatch();

  return (
    <div>
      <h2>Counter {state}</h2>
      <button onClick={() => dispatch(increment("Hello"))}>increment</button>
    </div>
  );
};

export default Counter;
