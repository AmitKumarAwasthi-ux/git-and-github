import "./App.css";
import { Provider } from "react-redux";
import Counter from "./Counter";
import { myStore } from "./redux/store";

function App() {
  return (
    <div>
      <h1> App Component </h1>

      <Provider store={myStore}>
        <Counter />
      </Provider>
    </div>
  );
}

export default App;
