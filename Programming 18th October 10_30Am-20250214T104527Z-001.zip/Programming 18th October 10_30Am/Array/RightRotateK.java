import java.util.*;
class RightRotatek
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={20, 30, 40, 50, 60, 70, 80, 90, 100};
		System.out.println("Original Array: "+Arrays.toString(a));
		System.out.println("ENter the Rotation value: ");
		int k=sc.nextInt();
		rightRotate(a,k);
		System.out.println("Rotated Array: "+Arrays.toString(a));		
	}
	public static void rightRotate(int[] a, int k){
		k=k%a.length;
		if(k==0)
			return;
		reverse(a, 0, a.length-1);
		reverse(a, 0, k-1);
		reverse(a, k, a.length-1);
	}
	public static void reverse(int[] a, int start, int end){
		while(start<end){
			int temp=a[start];
			a[start]=a[end];
			a[end]=temp;
			start++;	end--;
		}
	}
}




