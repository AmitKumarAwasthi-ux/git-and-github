import java.util.*;
class Frequency
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={2, 3, 4, 2, 1, 1, 1, 4, 4, 3, 6, 3, 4, 5, 4};
		getFrequency(a);		
	}
	public static void getFrequency(int[] a){
		int[] freq=new int[101];
		for(int i=0;i<a.length;i++)
			freq[a[i]]++;
		for(int i=0;i<freq.length;i++){
			if(freq[i]>0)
				System.out.println(i+" is "+freq[i]+" times");
		}
	}
}




