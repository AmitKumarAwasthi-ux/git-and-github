import java.util.*;
class Frequency1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={2, 3, -4, 2, -1, 1, -4, -4, 4, 3, 6, -3};
		getFrequency(a);		
	}
	public static void getFrequency(int[] a){
		int big=a[0], small=a[0];
		for(int x:a){
			if(x>big)
				big=x;
			if(x<small)
				small=x;
		}
		int[] freq=new int[big-small+1];
		for(int i=0;i<a.length;i++){
			freq[a[i]-small]++;
		}
		for(int i=0;i<freq.length;i++){
			if(freq[i]>0)
				System.out.println((i+small)+" is: "+freq[i]+" times");
		}
	}
}




