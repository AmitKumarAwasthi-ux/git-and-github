import java.util.*;
class BinarySearch1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={23, 24, 30, 34, 50, 54, 70, 88};
		System.out.println(Arrays.toString(a));
		System.out.println("ENter the Elements to Search: ");
		int target=sc.nextInt();
		int ind=search(a, target);
		if(ind>=0)
			System.out.println("Element "+target+" position "+ind);
		else
			System.out.println("Element "+target+" is NOT Found");
	}
	public static int  search(int[] a, int target){
		int low=0, high=a.length-1;	int mid=0;
		while(low<=high){
			mid=low+(high-low)/2;
			if(a[mid]==target)
				return mid;
			else if(a[mid]>target)
				high=mid-1;
			else
				low=mid+1;
		}
	return a[mid]>target ? mid : mid+1;	
	}
}




