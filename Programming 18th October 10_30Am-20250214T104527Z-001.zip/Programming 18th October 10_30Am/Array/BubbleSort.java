import java.util.*;
class BubbleSort
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={23, 12, 24, 20, 16, 12, 18, 8, 15, 17, 19};
		System.out.println("Before Sorting: "+Arrays.toString(a));
		sort(a);
		System.out.println("After Sorting: "+Arrays.toString(a));
	}
	public static void sort(int[] a){
		int n=a.length;
		for(int i=0;i<n-1;i++){
			int count=0;
			for(int j=0;j<n-1-i;j++){
				if(a[j]>a[j+1]){
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
					count++;
				}
			}
			if(count==0)
				return;
		}
	}
}




