import java.util.*;
class MergeSort
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={23, 12, 24, 20, 16, 12, 18, 8, 15, 17, 19};
		System.out.println("Before Sorting: "+Arrays.toString(a));
		divide(a, 0, a.length-1);
		System.out.println("After Sorting: "+Arrays.toString(a));
	}
	public static void divide(int[] a, int si, int ei){
		if(ei>si){
			int mid=si+(ei-si)/2;
			divide(a, si, mid);
			divide(a, mid+1, ei);
			merge(a, si, mid, ei);
		}
	}
	public static void merge(int[] a, int si, int mid, int ei){
		int[] merged=new int[ei-si+1];
		int indx1=si,indx2=mid+1, x=0;
		while(indx1<=mid && indx2<=ei){
			if(a[indx1]<=a[indx2])
				merged[x++]=a[indx1++];
			else
				merged[x++]=a[indx2++];
		}
		while(indx1<=mid)
			merged[x++]=a[indx1++];
		while(indx2<=ei)
			merged[x++]=a[indx2++];
		for(int i=0,j=si;i<merged.length;i++,j++)
			a[j]=merged[i];
	}
}




