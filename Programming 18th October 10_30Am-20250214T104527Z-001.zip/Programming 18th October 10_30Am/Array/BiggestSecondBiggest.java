import java.util.*;
class BiggestSecondBiggest
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={90, 90, 70, 45, 70, 45, 38};
		getBiggestSecondBiggest(a);		
	}
	public static void getBiggestSecondBiggest(int[] a){
		int largest=a[0];
		int secLargest=Integer.MIN_VALUE;
		for(int num:a){
			if(num>largest){
				secLargest=largest;
				largest=num;
			}else if(num>secLargest && num!=largest)
				secLargest=num;
		}
		System.out.println("Largest is: "+largest);
		System.out.println("Second Largest is: "+secLargest);
		
	}
}




