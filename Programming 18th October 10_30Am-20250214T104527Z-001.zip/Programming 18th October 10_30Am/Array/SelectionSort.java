import java.util.*;
class SelectionSort
{
	public static void main(String[] args)
	{
		int[] a={23, 12, 24, 20, 16, 12, 18, 8, 15, 17, 19};
		System.out.println("Before Sorting: "+Arrays.toString(a));
		sort(a);
		System.out.println("After Sorting: "+Arrays.toString(a));
	}
	public static void sort(int[] a){
		for(int i=0;i<a.length-1;i++){
			int min=a[i], ind=i;
			for(int j=i+1;j<a.length;j++){
				if(a[j]<min){
					min=a[j];
					ind=j;
				}
			}
			a[ind]=a[i];
			a[i]=min;
		}
	}
}




