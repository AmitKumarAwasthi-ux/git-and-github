class Program1
{
	public static void main(String[] args)
	{
		int[] a=new int[10];
		for(int x:a)
			System.out.println(x);	
		a[0]=34;
		a[3]=44;
		a[7]=90;
		a[8]=45;
		System.out.println("=============");
		for(int x:a)
			System.out.println(x);	
		
	}
}