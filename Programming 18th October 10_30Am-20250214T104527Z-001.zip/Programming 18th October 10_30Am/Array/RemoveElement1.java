import java.util.*;
class RemoveElement1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int[] a={23, 45, 34, 56, 45, 56, 45, 67, 45};
		System.out.println("Original Array: "+Arrays.toString(a));
		System.out.println("ENter the index to Remove: ");
		int ind=sc.nextInt();
		a=removeElement(a,ind);
		System.out.println("New      Array: "+Arrays.toString(a));		
	}
	public static int[] removeElement(int[] a, int index){
		if(index>=a.length){
			System.out.println("Given Index is not Availaible");
		return a;
		}
		int[] b=new int[a.length-1];
		for(int i=0;i<b.length;i++){
			if(i<index)
				b[i]=a[i];
			else
				b[i]=a[i+1];
		}
	return b;
	}
}




