import java.util.Scanner;
class Service
{
	public void getAllCars(Car[] c){
		for(Car x:c)
			System.out.println(x);
	}
	public void getAllCarsByName(Car[] c){
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Name: ");
		String name=sc.nextLine();
		for(Car x:c){
			if(x.name.equalsIgnoreCase(name))
				System.out.println(x);
		}
	}
	/*public void getHighestAndLeastPriceCar(Car[] c){
		double highestPrice=c[0].price;
		double lowestPrice=c[0].price;
		for(Car x:c){
			if(x.price>highestPrice)
				highestPrice=x.price;
			if(x.price<lowestPrice)
				lowestPrice=x.price;
		}
	System.out.println("Car With Highest Price is: "+highestPrice);
	System.out.println("Car With Lowest Price is: "+lowestPrice);
	}*/
	public void getHighestAndLeastPriceCar(Car[] c){
		Car high=c[0];
		Car low=c[0];
		for(Car x:c){
			if(x.price>high.price)
				high=x;
			if(x.price<low.price)
				low=x;
		}
		System.out.println("Car Details With Highest Price is: ");
		System.out.println(high);
		System.out.println("Car Details With Lowest Price is: ");
		System.out.println(low);

	}
}



