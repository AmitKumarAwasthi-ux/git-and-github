class Driver
{
	public static void main(String[] args)
	{
		Car[] c=new Car[5];
		c[0]=new Car("TATA", 38436.45, "black");
		c[1]=new Car("Maruti", 45436.45, "white");
		c[2]=new Car("tata", 30436.45, "white");
		c[3]=new Car("BMW", 55436.45, "red");
		c[4]=new Car("Audi", 45400.45, "White");
		System.out.println("ACcess All Cars");
		Service service=new Service();
		service.getAllCars(c);
		/*System.out.println("======================");
		service.getAllCarsByName(c);*/	
		System.out.println("======================");
		service.getHighestAndLeastPriceCar(c);
		
	}
}