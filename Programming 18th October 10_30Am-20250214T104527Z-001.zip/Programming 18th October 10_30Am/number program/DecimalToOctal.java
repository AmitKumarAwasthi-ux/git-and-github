import java.util.Scanner;
class DecimalToOctal
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		String octal=convertDecimalToOctal(n);
		System.out.println("Octal of "+n+" is: "+octal);
	}
	public static String convertDecimalToOctal(int n){
		String oct="";
		while(n>0){
			int rem=n%8;
			oct=rem+oct;
		n=n/8;
		}
	return oct;
	}
}











