import java.util.Scanner;
class OctalToDecimal1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Octal Number: ");
		String s=sc.nextLine();
		String result=convertOctalToDecimal(s);
		System.out.println(result);
	}
	public static String convertOctalToDecimal(String s){
		int dec=0;	int eightmul=1;
		for(int i=s.length()-1;i>=0;i--){
			char c=s.charAt(i);
			if(c>=48 && c<=55)
				dec=dec+(c-48)*eightmul;
			else
				return "The Invalid Input is Provided";
		eightmul*=8;
		}
	return "The Decimal Value is: "+dec;
	}
}











