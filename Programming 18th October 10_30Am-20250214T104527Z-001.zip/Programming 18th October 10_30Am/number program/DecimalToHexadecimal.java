import java.util.Scanner;
class DecimalToHexadecimal
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		String hexadecimal=convertDecimalToHexadecimal(n);
		System.out.println("Hexadecimal of "+n+" is: "+hexadecimal);
	}
	public static String convertDecimalToHexadecimal(int n){
		String hex="";
		while(n>0){
			int rem=n%16;
			if(rem<=9)
				hex=rem+hex;
			else
				hex=(char)(rem+55)+hex;
		n=n/16;
		}
	return hex;
	}
}











