import java.util.Scanner;
class OctalToDecimal
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Octal Number: ");
		int n=sc.nextInt();
		String result=convertOctalToDecimal(n);
		System.out.println(result);
	}
	public static String convertOctalToDecimal(int n){
		int dec=0;	int eightmul=1;
		while(n>0){
			int rem=n%10;
			if(rem>=0 && rem<=7)
				dec=dec+eightmul*rem;
			else
				return "The input provided is Invalid";
		n=n/10;
		eightmul*=8;
		}
	return "The Decimal Value is: "+dec;
	}
}











