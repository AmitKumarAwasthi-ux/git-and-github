package varargs_program;

public class Program1 {
	public static void main(String[] args) {
		getSum(12, 34, 45);
		getSum(12, 34, 45, 56, 56);
		getSum(20, 30);
		getSum();
	}
	public static void getSum(int... a) {
		int sum=0;
		for(int x:a) {
			sum=sum+x;
		}
		System.out.println("Sum is: "+sum);
	}
}
