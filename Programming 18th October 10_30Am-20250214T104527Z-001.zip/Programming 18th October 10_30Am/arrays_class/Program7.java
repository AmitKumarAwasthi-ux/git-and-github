package arrays_class;
import java.util.Arrays;
public class Program7 {
	public static void main(String[] args) {
		int[] a= {1, 8, 3};
		int[] b= {1, 5, 2};
		int[] c= {1, 8, 3};
		int[] d= {1, 10, 7};
		System.out.println(Arrays.compare(a, b));
		System.out.println(Arrays.compare(a, c));
		System.out.println(Arrays.compare(a, d));
	}

}
