package arrays_class;

import java.util.Arrays;

public class Program3 {
	public static void main(String[] args) {
		int[] a= {12, 34, 40, 55, 65, 70, 78};
		System.out.println(Arrays.toString(a));
		int ind=Arrays.binarySearch(a, 66);
		System.out.println("Index is: "+ind);
	}

}
