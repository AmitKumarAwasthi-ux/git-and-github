package arrays_class;
import java.util.Arrays;
public class Program2 {
	public static void main(String[] args) {
		int[] a= {12, 34, 10, 55, 35, 63, 48};
		System.out.println("Before Sorting: "+Arrays.toString(a));
		Arrays.sort(a);
		System.out.println("After Sorting: "+Arrays.toString(a));
	}

}
