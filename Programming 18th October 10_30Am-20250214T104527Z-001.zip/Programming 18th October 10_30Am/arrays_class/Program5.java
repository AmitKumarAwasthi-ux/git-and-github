package arrays_class;

import java.util.Arrays;

public class Program5 {
		public static void main(String[] args) {
			int[] a= {12, 34, 40};
			int[] b= {12, 40, 34};
			System.out.println(Arrays.equals(a, b));
	}
}
