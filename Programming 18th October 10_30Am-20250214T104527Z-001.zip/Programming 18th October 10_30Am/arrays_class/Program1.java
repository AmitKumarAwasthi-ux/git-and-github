package arrays_class;
import java.util.*;
public class Program1 {
	public static void main(String[] args) {
		int[] a= {12, 34, 10, 55, 35, 63, 48};
		String arr=Arrays.toString(a);
		System.out.println(a);
		System.out.println(arr);
	}

}
