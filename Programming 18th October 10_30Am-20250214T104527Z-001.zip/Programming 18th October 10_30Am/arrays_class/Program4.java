package arrays_class;

import java.util.Arrays;

public class Program4 {
	public static void main(String[] args) {
		int[] a= {12, 34, 40, 55, 65, 70, 78};
		System.out.println(Arrays.toString(a));
		int ind=Arrays.binarySearch(a, 0, 2, 70);
		System.out.println("Index is: "+ind);
	}

}
