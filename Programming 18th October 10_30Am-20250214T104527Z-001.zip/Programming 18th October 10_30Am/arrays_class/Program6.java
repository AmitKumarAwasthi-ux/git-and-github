package arrays_class;

import java.util.Arrays;

public class Program6 {
	public static void main(String[] args) {
		int[] a= {12, 34, 40};
		int[] b= {12, 40, 34};
		Arrays.sort(a);
		Arrays.sort(b);
		System.out.println(Arrays.equals(a,b));
	}

}
