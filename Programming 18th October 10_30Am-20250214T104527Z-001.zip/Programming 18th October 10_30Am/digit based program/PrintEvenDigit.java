import java.util.Scanner;
class PrintEvenDigit
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		System.out.println("All Even digits are below====");
		while(n>0){
			int rem=n%10;
			if(rem%2==0)
				System.out.println(rem);
		n=n/10;
		}
	}
}