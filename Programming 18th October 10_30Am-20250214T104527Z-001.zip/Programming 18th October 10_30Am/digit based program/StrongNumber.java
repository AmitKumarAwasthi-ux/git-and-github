import java.util.Scanner;
class StrongNumber
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		int sum=0;
		int originalNum=n;
		while(n>0){
			int rem=n%10;
			int fact=1;
			int i=1;
			while(i<=rem){
				fact=fact*i;
			i++;
			}
		sum=sum+fact;
		n=n/10;
		}
		if(sum==originalNum)
			System.out.println(originalNum+" is a Strong Number");
		else
			System.out.println(originalNum+" is NOT a Strong Number");
	}
}