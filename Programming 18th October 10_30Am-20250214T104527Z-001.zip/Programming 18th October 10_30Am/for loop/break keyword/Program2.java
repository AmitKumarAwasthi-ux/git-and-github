class Program2
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		for(int i=1;;i++)
		{
			if(i>=25)
				break;
			System.out.println("Java Program: "+i);	
		}
		System.out.println("Main Ends");
	}
}