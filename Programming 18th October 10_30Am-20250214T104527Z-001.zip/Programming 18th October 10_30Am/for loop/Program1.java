class Program1
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		for(int i=1;i<=10;i++)
		{
			System.out.println("Java Program: "+i);
		}
		System.out.println("Main Ends");
	}
}