class Program4
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		int i=1;
		for(;i<=10;)
		{
			System.out.println("Java Program: "+i);
		i++;
		}
		System.out.println("Main Ends and i is: "+i);
	}
}