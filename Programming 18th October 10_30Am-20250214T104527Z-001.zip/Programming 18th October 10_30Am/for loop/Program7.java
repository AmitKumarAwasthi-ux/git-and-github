class Program7
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		for(int i=1,j=10;;i++,j--)
		{
			System.out.println("i: "+i+" j: "+j);
		}
	}
}