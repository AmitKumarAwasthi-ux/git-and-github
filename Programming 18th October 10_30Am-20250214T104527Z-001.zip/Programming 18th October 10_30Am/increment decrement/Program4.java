class Program4
{
	public static void main(String[] args)
	{

		System.out.println(045>100);
		System.out.println(0b10000>40);
		System.out.println(0x45>50);
		
	}
}