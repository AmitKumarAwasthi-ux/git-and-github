class Program1
{
	public static void main(String[] args)
	{
		int x=18;
		int y=x++;
		int z=++y;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);
	}
}