class Pattern3
{
	public static void main(String[] args)
	{
		String s1="Mohan Is Here";
		System.out.printf("%30s\n", s1);
		System.out.printf("%S", s1);


	}
}