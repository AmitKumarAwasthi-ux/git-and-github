
class Pattern1
{
	public static void main(String[] args)
	{
		int x=23; int y=456; int z=4565;
		int p=45654; int q=477; int r=45;
		System.out.println(x+" "+y+" "+z);
		System.out.println(p+" "+q+" "+r);
	}
}