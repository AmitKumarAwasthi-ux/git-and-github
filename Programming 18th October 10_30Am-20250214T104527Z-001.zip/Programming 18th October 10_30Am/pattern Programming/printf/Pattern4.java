class Pattern4
{
	public static void main(String[] args)
	{
		int x=45;
		double y=344565.5;
		String s1="Mohan Is Here";
		System.out.printf("%5d%4.2f%10s", x,y,s1);


	}
}