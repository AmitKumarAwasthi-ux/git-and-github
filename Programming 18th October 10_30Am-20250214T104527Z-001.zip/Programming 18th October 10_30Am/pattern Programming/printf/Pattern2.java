class Pattern2
{
	public static void main(String[] args)
	{
		int x=23; int y=456; int z=4565;
		int p=45654; int q=477; int r=45;
		System.out.printf("%5d%5d  %5d\n",x,y,z);
		System.out.printf("%5d%5d  %5d\n",p,q,r);

	}
}