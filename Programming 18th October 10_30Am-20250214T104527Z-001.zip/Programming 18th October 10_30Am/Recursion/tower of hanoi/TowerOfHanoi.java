import java.util.Scanner;
class TowerOfHanoi
{
	static int count=0;
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number of Disk: ");
		int n=sc.nextInt();
		solveHanoi(n, 'A', 'C', 'B');
		System.out.println("Total Steps are: "+count);
	}
	public static void solveHanoi(int n, char from, char to, char aux){
		count++;
		if(n==1){
			System.out.println("Move Disk from tower "+from+" to tower "+to);
			return;
		}
		solveHanoi(n-1, from, aux, to);
		System.out.println("Move Disk from tower "+from+" to tower "+to);
		solveHanoi(n-1,aux, to, from);
	}
}




