import java.util.Scanner;
class DigitSum
{
	static int sum=0;
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		getDigitSum(n);
	}
	public static void getDigitSum(int n){
		if(n>0){
			sum=sum+n%10;
			getDigitSum(n/10);
		}
		else
			System.out.println("Total Digit Sum is: "+sum);
	}
}