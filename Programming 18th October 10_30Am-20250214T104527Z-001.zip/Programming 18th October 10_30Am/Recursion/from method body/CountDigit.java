import java.util.Scanner;
class CountDigit
{
	static int count=0;
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Number: ");
		int n=sc.nextInt();
		counDigit(n);
	}
	public static void counDigit(int n){
		if(n>0){
			count++;
			counDigit(n/10);
		}
		else
			System.out.println("Total Digit is: "+count);
	}
}