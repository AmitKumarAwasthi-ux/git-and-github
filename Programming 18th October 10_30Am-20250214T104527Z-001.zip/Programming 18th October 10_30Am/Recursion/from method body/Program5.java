class Program5
{
	static int count=11;
	public static void main(String[] args)
	{
		printNum();
	}
	public static void printNum(){
		count--;
		if(count>0){
			System.out.println(count);
			printNum();
		}
	}
}