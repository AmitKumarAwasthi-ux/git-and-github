class Program3
{
	static int count=0;
	public static void main(String[] args)
	{
		System.out.println("main starts");
		test();
		System.out.println("Main Ends");
	}
	public static void test(){
		count++;
		if(count<=2){
			System.out.println("Inside if count is: "+count);
			test();
			System.out.println("If Ends");
		}
		else{
			System.out.println("Inside else count is: "+count);
		}
	}
}