class Program4
{
	static int count=0;
	public static void main(String[] args)
	{
		printNum();
	}
	public static void printNum(){
		count++;
		if(count<=10){
			System.out.println(count);
			printNum();
		}
	}
}