class Sum
{
	static int count=0;	static int sum=0;
	public static void main(String[] args)
	{
		printNum();
	}
	public static void printNum(){
		count++;
		if(count<=10){
			
			sum=sum+count;
			printNum();
		}
		else
			System.out.println("SUm is: "+sum);
	}
}