import java.util.Scanner;
class Sum1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Upper Range: ");
		int uRange=sc.nextInt();
		System.out.println("ENter the Lower Range: ");
		int lRange=sc.nextInt();
		int sum=getSum(uRange,lRange);
		System.out.println("SUm is: "+sum);
	}
	public static int getSum(int uR, int lR){
		if(uR>lR)
			return uR+getSum(uR-1, lR);
		else
			return lR;
	}
}




