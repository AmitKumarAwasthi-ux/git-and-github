import java.util.Scanner;
class Sum
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the Range: ");
		int range=sc.nextInt();
		int sum=getSum(range);
		System.out.println("SUm is: "+sum);
	}
	public static int getSum(int n){
		if(n>1)
			return n+getSum(n-1);
		else
			return n;
	}
}




