import java.util.Scanner;
class FindBiggest
{
	static int count=0;
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the 1st Number: ");
		int n1=sc.nextInt();
		System.out.println("ENter the next Number: ");
		int n2=sc.nextInt();
		System.out.println("ENter the next Number: ");
		int n3=sc.nextInt();
		System.out.println("ENter the next Number: ");
		int n4=sc.nextInt();
		int big=getBig(getBig(n1,n2),getBig(n3, n4));
		System.out.println("Biggest is: "+big);
	}
	public static int getBig(int n1, int n2){
	return n1>n2?n1:n2;
	}
}