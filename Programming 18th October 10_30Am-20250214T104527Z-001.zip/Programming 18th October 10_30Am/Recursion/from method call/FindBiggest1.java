import java.util.Scanner;
class FindBiggest1
{
	static int count=0;
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the 1st Number: ");
		int n1=sc.nextInt();
		int big=n1;
		char c;
		do{
			System.out.println("ENter the next Number: ");
			int n2=sc.nextInt();
			big=big(big,n2);
		System.out.println("Press Y/y to enter the next Number: ");
		c=sc.next().charAt(0);
		}while(c=='Y' || c=='y');
		System.out.println("Biggest is: "+big);
	}
	public static int big(int n1, int n2){
	return n1>n2?n1:n2;
	}
}