package splitMethod;

public class ReverseEachWord {
	public static void main(String[] args) {
		String s1="Mohan and Sohan are here";
		reverseWord(s1);
		
	}
	public static void reverseWord(String s1) {
		String[] s=s1.split("\\s+");
		
		for(int i=0;i<s.length;i++) {
			String p=s[i];
			for(int j=p.length()-1;j>=0;j--) {
				System.out.print(p.charAt(j));
			}
			System.out.print(" ");
		}
		
	}

}
