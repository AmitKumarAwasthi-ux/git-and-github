package splitMethod;
import java.util.*;
public class ReverseWord {
	public static void main(String[] args) {
		String s1="Mohan and Sohan are here";
		reverseWord(s1);
		
	}
	public static void reverseWord(String s1) {
		String[] s=s1.split("\\s+");
		int lastIndex=s.length-1;
		for(int i=0;i<s.length;i++) {
			System.out.print(s[lastIndex-i]+" ");
			
		}
		
	}

}
