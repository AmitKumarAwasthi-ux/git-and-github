package splitMethod;

public class Program21 {
	public static void main(String[] args) {
		String s1="mohan is here. sohan is here. john is here";
		String[] arr=s1.split("[.]");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
