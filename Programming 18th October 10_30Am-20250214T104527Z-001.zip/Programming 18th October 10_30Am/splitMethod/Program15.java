package splitMethod;

public class Program15 {
	public static void main(String[] args) {
		String s1="25c40def8cd124dd234";
		String[] arr=s1.split("\\D+");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
