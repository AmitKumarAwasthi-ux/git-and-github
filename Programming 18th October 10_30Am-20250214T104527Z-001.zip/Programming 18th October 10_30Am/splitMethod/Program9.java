package splitMethod;

public class Program9 {
	public static void main(String[] args) {
		String s1="deacdeaacaaaddabe";
		String[] arr=s1.split("(a)");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}
	

}
