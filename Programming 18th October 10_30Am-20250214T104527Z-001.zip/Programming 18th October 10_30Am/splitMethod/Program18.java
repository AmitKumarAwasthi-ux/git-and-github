package splitMethod;

public class Program18 {
	public static void main(String[] args) {
		String s1="*ab25cde@40de&8cd1#24dd";
		String[] arr=s1.split("[a-zA-Z0-9]+");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
