package splitMethod;

public class Program6 {
	public static void main(String[] args) {
		String s1="ab@cd!@#de$ee";
		String[] arr=s1.split("!@#");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}
	

}
