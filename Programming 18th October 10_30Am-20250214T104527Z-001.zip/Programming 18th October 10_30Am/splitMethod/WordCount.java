package splitMethod;
import java.util.Scanner;
public class  WordCount{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		int count=getWordCount(s1);
		System.out.println("Total Words are: "+count);
		
	}
	public static int getWordCount(String s) {
	return s.stripLeading().split("\s+").length;
	}

}
