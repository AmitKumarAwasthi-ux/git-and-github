package splitMethod;

public class Program14 {
	public static void main(String[] args) {
		String s1="ab25cde40de8cd124dd";
		String[] arr=s1.split("\\d+");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
