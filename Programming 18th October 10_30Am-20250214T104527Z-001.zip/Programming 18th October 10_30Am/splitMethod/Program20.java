package splitMethod;

public class Program20 {
	public static void main(String[] args) {
		String s1="abDcefTddABcce";
		String[] arr=s1.split("\\p{Upper}+");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
