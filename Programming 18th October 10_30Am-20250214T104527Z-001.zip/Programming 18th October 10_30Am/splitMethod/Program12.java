package splitMethod;

public class Program12 {
	public static void main(String[] args) {
		String s1="abc@!cd$e@!p";
		String[] arr=s1.split("[@!$]");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
