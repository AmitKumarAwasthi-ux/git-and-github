package splitMethod;

public class Program19 {
	public static void main(String[] args) {
		String s1="ab25cDe@40dE&8cd1#24dd";
		String[] arr=s1.split("[^a-z]+");
		System.out.println("length is: "+arr.length);
		for(String s:arr)
			System.out.println(s);
	}

}
