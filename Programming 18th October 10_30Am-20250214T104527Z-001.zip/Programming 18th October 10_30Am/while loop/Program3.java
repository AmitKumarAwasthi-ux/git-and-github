//+ve direction infinite loop
class Program3
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		int i=1;
		while(i>0){
			System.out.println("Java Program: "+i);
		i++;
		}
	}
}