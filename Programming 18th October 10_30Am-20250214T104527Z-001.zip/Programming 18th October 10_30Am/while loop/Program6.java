class Program6
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		int i=1;
		while(i<=100){
			System.out.print(i+" ");
		i++;
		}
	}
}