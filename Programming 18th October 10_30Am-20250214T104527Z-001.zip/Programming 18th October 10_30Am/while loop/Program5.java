class Program5
{
	public static void main(String[] args)
	{
		System.out.println("main starts");
		int i=1;
		while(i<=100){
			System.out.println(i);
		i++;
		}
	}
}