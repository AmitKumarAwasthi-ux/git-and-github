class Program1
{
	public static void main(String[] args)
	{
		int a=12;
		int b=6;
		int c=4;
		a+=(b-c)/2;
		System.out.println("a is: "+a);
	
	}
}