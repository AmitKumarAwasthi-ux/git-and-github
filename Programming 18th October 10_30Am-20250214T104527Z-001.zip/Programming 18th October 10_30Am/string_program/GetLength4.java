package string_program;

import java.util.Scanner;

public class GetLength4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		int len=getLength(s1);
		System.out.println("Length of "+s1+" is: "+len);
	}
	public static int getLength(String s) {
		s=s+'\0';
		int count=0;
		for(int i=0;;i++) {
			if(s.charAt(i)!='\0')
				count++;
			else 
				break;
		}
	return count;
	}
}
