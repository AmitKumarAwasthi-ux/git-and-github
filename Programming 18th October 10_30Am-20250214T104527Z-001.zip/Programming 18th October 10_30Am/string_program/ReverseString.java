package string_program;

import java.util.Scanner;

public class ReverseString {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		String s2=reverseString(s1);
		System.out.println("Reverse of "+s1+" is: "+s2);
	}
	public static String reverseString(String s) {
		char[] c=s.toCharArray();
		for(int i=0;i<c.length/2;i++) {
			char temp=c[i];
			c[i]=c[c.length-1-i];
			c[c.length-1-i]=temp;
		}
	return new String(c);
	}

}
