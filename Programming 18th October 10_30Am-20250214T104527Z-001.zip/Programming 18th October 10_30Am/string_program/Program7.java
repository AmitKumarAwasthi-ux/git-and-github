package string_program;

public class Program7 {
	public static void main(String[] args) {
		char[] p= {'m','o','h','a','n'};
		System.out.println(p);
		String k=new String(p);
		System.out.println(k);
		System.out.println("=============");
		String pwd="mohan12@#";
		char[] pwd1=new char[] {'m','o','h','a','n','1','2','@','#'};
		System.out.println(pwd);
		System.out.println(pwd1);
	}
}
