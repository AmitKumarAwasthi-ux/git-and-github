package string_program;

public class Program5 {
	public static void main(String[] args) {
		String s1="    mohan      ";
		System.out.println(s1);
		s1=s1.trim();
		System.out.println(s1);
		String s2="mohan is here";
		System.out.println(s2);
		s2=s2.indent(4);
		System.out.println(s2);
		s2=s2.repeat(5);
		System.out.println(s2);
	}

}
