package string_program;

import java.util.Scanner;

public class Program6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String :");
		String s1=sc.nextLine();
		String s2=removeDuplicates(s1);
		System.out.println("Original String is: "+s1);
		System.out.println("Unique Character is: "+s2);
	}
	public static String removeDuplicates(String s1) {
		String unique="";
		for(char c: s1.toCharArray()) {
			if(!unique.contains(c+""))
				unique=unique+c;
		}
	return unique;
	}
}
