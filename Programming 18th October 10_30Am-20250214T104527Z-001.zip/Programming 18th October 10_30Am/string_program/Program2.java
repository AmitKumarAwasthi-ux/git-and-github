package string_program;
public class Program2 {
	public static void main(String[] args) {
		String s1="abcd";
		String s2=new String("abxyz");
		char[] c= {'a', 'p', 'k'};
		String s3=new String(c);
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
	}

}
