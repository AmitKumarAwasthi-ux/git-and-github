package string_program;

public class Program4 {
	public static void main(String[] args) {
		String s1="mohan";
		String s2=new String("mohan");
		String s3=new String("mohan").intern();
		String s4=new String("mohan");
		s4=s4.intern();
		System.out.println(s1==s3);
		System.out.println(s3==s4);
		System.out.println(s3==s2);
	}

}
