package string_program;

import java.util.Scanner;

public class Palindrome1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		if(isPalindrome(s1))
			System.out.println("It is Palindrome");
		else
			System.out.println("IT is NOt paindrome");
	}
	public static boolean isPalindrome(String s) {
		char[] c=s.toCharArray();
		for(int i=0;i<c.length/2;i++) {
			char temp=c[i];
			c[i]=c[c.length-1-i];
			c[c.length-1-i]=temp;
		}
	return new String(c).equalsIgnoreCase(s);
	}

}
