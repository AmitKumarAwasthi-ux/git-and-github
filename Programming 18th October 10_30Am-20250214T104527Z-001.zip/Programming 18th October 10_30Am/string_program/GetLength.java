package string_program;
import java.util.*;
public class GetLength {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		int len=getLength(s1);
		System.out.println("Length of "+s1+" is: "+len);
	}
	public static int getLength(String s) {
		int count=0;
		try {
			for(int i=0;;i++) {
				s.charAt(i);
				count++;
			}
		}catch(Exception e) {
		return count;
		}
			
	}

}
