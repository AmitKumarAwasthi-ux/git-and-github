package string_program;

import java.util.Scanner;

public class CountWord {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		int count=getWordCount(s1);
			System.out.println("Total Words are: "+count);
	}
	public static int getWordCount(String s) {
		int count=0;
		for(int i=0;i<s.length();i++) {
			char c=s.charAt(i);
			if(i==0 && c!=' ' || c!=' '&& s.charAt(i-1)==' ')
				count++;
		}
	return count;
	}

}
