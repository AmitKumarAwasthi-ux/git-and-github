package string_program;

public class Program3 {
	public static void main(String[] args) {
		String s1="mohan";
		System.out.println(s1);
		s1=s1+'\0';
		s1=s1+"abc";
		System.out.println(s1);
		System.out.println(s1.indexOf('\0'));
	}

}
