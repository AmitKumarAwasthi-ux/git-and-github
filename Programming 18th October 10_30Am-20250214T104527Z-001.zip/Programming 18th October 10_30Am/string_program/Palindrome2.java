package string_program;

import java.util.Scanner;

public class Palindrome2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		String s1=sc.nextLine();
		if(isPalindrome(s1))
			System.out.println("It is Palindrome");
		else
			System.out.println("IT is NOt paindrome");
	}
	public static boolean isPalindrome(String s) {
		s=s.toUpperCase();
		int len=s.length();
		for(int i=0;i<len/2;i++) {
			char c=s.charAt(i);
			if(c!=s.charAt(len-1-i))
				return false;
		}
	return true;
	}

}
