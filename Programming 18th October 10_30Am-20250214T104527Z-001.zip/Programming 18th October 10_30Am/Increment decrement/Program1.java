class Program1
{
	public static void main(String[] args)
	{
		int a=18;
		System.out.println(a++);
		System.out.println(a++);
		System.out.println(++a);
		System.out.println(a++);
		System.out.println(a--);
		System.out.println(--a);
		System.out.println(++a);
		System.out.println(a++);
		System.out.println(++a);
	}
}